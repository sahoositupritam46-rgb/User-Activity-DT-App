var ct=()=>typeof globalThis<"u"?globalThis:window;function H(t){let n=O();typeof n=="function"?n(t):console.warn("Missing addGlobalErrorSerializer function from web runtime.")}function L(){return typeof O()=="function"}function O(){return ct().dtRuntime?.errorHandlers?.addGlobalErrorSerializer}var P=(t=>(t.COMMON="JS Error",t.HTTP="Http Error",t))(P||{});function w(t){return t?.name==="AbortError"}function f(t){return t?.name==="ResponseError"}var re=globalThis.AbortController,se=globalThis.AbortSignal,R=class extends Error{constructor(t,n){super(t),this.cause=n}},I=class extends R{name="UnsupportedOperationError";constructor(t,n){super(t,n)}};function lt(t,n){let r=new Response(t);switch(n){case"text":return r.text();case"json":return r.json();case"array-buffer":return r.arrayBuffer();case"blob":return r.blob();case"readable-stream":return r.body}throw new I(`Unsupported binary type: ${n}.`)}var k=class S{constructor(n){this.data=n}static fromText(n){return new S(new Blob([n]))}static fromJson(n){return new S(new Blob([JSON.stringify(n)]))}static from(n){if(n instanceof Blob||n instanceof ArrayBuffer||n instanceof ReadableStream)return new S(n);throw new I("Unsupported binary type.")}get(n){return lt(this.data,n)}};function J(t){return typeof t.get=="function"}var x=class extends R{name="DataTypeError";constructor(t,n){super(t,n)}},ut=t=>200<=t&&t<300;function Y(t){return String(t)}function Q(t){return JSON.stringify(t)}async function dt(t){if(t instanceof ArrayBuffer||t instanceof Blob)return t;if(t instanceof ReadableStream)return new Response(t).arrayBuffer();if(J(t))return t.get("array-buffer");throw new x("Cannot encode form data field as binary type.")}async function pt(t){let n=new FormData;for(let r of t)switch(r.type){case"text":n.append(r.name,Y(r.value));break;case"json":n.append(r.name,new Blob([Q(r.value)],{type:r.contentType??"application/json"}),r.filename??"json");break;case"binary":{if(File&&r.value instanceof File){let e=r.value;n.append(r.name,new File([e],r.filename??e.name,{type:r.contentType??e.type??"application/octet-stream",lastModified:e.lastModified}),r.filename??e.name)}else{let e="type"in r.value?r.value.type:void 0;n.append(r.name,new Blob([await dt(r.value)],{type:r.contentType??e??"application/octet-stream"}),r.filename??"binary")}break}}return n}async function ht(t){if(t instanceof Blob||t instanceof ArrayBuffer||t instanceof ReadableStream)return t;if(J(t))try{return await t.get("array-buffer")}catch(n){throw new x("Cannot encode body as binary type.",n)}else throw new x("Cannot encode body as binary type.")}async function wt(t,n){switch(n){case"text":return Y(t);case"json":return Q(t);case"form-data":return await pt(t);case"binary":return await ht(t)}throw new x(`Invalid body type: '${n}'`)}function ft(t){switch(t){case"json":return"application/json";case"text":return"text/plain";case"binary":return"application/octet-stream"}throw new x(`Invalid body type: '${t}'`)}function yt(t){if(t["Content-Type"]?.startsWith("multipart/")){let{"Content-Type":n,...r}=t;return r}return t}function mt(t,n){let r=t?yt(t):void 0;return!Object.keys(r??{}).some(a=>a.toLowerCase()==="content-type")&&n!=="form-data"?{"content-type":ft(n),...r}:r}var At=class extends Error{constructor(t){super(typeof t?.message=="string"?`Request aborted: ${t.message}`:"Request aborted."),this.cause=t}name="AbortError"},B=t=>{if(t instanceof Error&&t.name==="AbortError")throw new At(t)},Et=class extends R{constructor(t){super(typeof t?.message=="string"?`Request failed: ${t.message}`:"Request failed."),this.cause=t}name="RequestError"};function W(t){if(t!==void 0)return String.fromCharCode(t)}function bt(t){return["application/json","text/plain"].includes(String(t).toLowerCase())}function K(t){return t&&JSON.parse(`"${t}"`)}function gt(t){let n=K(/form-data;.*filename="((?:[^"\\]|\\.)*)"/gm.exec(t)?.[1]);return{name:K(/form-data;.*(?<!file)name="((?:[^"\\]|\\.)*)"/gm.exec(t)?.[1]),fileName:n}}function vt(t){return/multipart\/form-data;boundary=(.*)/gm.exec(t)?.[1]}var Ct=class{constructor(t,n){this.sourceArray=t,this.boundary=n}currentChar=null;currentByte=null;offset=0;utf8Decoder=new TextDecoder("utf-8");get previousByte(){return this.sourceArray[this.offset-2]}get previousChar(){return W(this.previousByte)}next(){return this.offset>=this.sourceArray.byteLength?(this.currentChar=null,this.currentByte=null,!1):(this.currentByte=this.sourceArray[this.offset],this.currentChar=String.fromCharCode(this.currentByte),this.offset++,!0)}charAt(t){return W(this.sourceArray[t])??null}nextChar(){return this.next(),this.currentChar}nextByte(){return this.next(),this.currentByte}get nextTwoChars(){return String.fromCharCode(this.sourceArray[this.offset],this.sourceArray[this.offset+1])}findNextBoundaryOffset(t=this.offset){let n=0,r=!1,e=t,a=this.charAt(e);for(;!r;){if(a===null)return null;a===this.boundary[n]?(n++,n===this.boundary.length&&(r=!0)):n=0,e++,a=this.charAt(e)}return e-this.boundary.length}skipPastNextBoundary(){let t=this.findNextBoundaryOffset();if(t===null)return!1;this.offset=t+this.boundary.length,this.currentByte=this.sourceArray[this.offset],this.currentChar=String.fromCharCode(this.currentByte);let n=this.nextTwoChars;return n=="--"?!1:(n==`\r
`&&(this.offset++,this.next()),!0)}readLine(){let t=[];do{let n=this.nextByte();if(n===null)return null;t.push(n)}while(this.currentChar!==null&&this.currentChar!==`
`&&this.previousChar!=="\r");return Uint8Array.from(t)}readSectionHeaders(){let t={},n=this.offset,r=!1;for(;!r;){let a=this.readLine();if(a===null)throw TypeError("Unexpected end of response while parsing headers");let s=this.utf8Decoder.decode(a);if(s===`\r
`){r=!0;break}let[o,h]=s.split(":").map(m=>(m??"").trim());t[o.toLowerCase()]=h}return{headersLength:this.offset-n,headers:t}}extractData(){let t=this.findNextBoundaryOffset()??this.sourceArray.length,r=String.fromCharCode(this.sourceArray[t-2],this.sourceArray[t-1])===`\r
`?t-2:t,e=this.sourceArray.slice(this.offset,r);return{payloadStartOffset:this.offset,payloadEndOffset:r,data:e}}parse(){let t=[];for(;this.skipPastNextBoundary();){let n=this.offset,{headers:r}=this.readSectionHeaders(),{data:e,payloadStartOffset:a,payloadEndOffset:s}=this.extractData(),o=bt(r["content-type"]),{name:h,fileName:m}=gt(r["content-disposition"]);t.push({name:h,text:o?this.utf8Decoder.decode(e):void 0,file:o?void 0:new File([e],m??"",{type:r["content-type"]??"application/octet-stream"}),rawData:e,headers:r,headersStartOffset:n,payloadStartOffset:a,payloadEndOffset:s})}return t}};function xt(){return/apple/i.test(navigator.vendor)}function _t(t,n){return new Ct(t,n).parse()}function $t(){return new ReadableStream({start(t){t.close()}})}async function kt(t){return t.body!==null?t.text():""}async function St(t){return t.body!==null?t.json():null}async function Rt(t){return k.from(Z(t))}async function Ut(t){if(t.body===null)return[];{let n=[];if(xt()){let r=await t.clone(),e=new Uint8Array(await r.arrayBuffer()),a=vt(r.headers.get("content-type")),s=_t(e,`--${a}`);(await t.formData()).forEach((h,m)=>{let g=s.find(({name:C})=>C===m);typeof h=="string"&&g?.file!==void 0?n.push({type:"binary",name:m,contentType:g.headers["content-type"],filename:g.file.name,value:k.from(g.file)}):h instanceof File?n.push({type:"binary",name:m,contentType:h.type,filename:h.name,value:k.from(h)}):n.push({type:"text",name:m,value:h})})}else(await t.formData()).forEach((e,a)=>{e instanceof File?n.push({type:"binary",name:a,contentType:e.type,filename:e.name,value:k.from(e)}):n.push({type:"text",name:a,value:e})});return n}}async function jt(t){return t!==null?t.arrayBuffer():new ArrayBuffer(0)}async function Dt(t){return t!==null?t.blob():new Blob}function Z(t){return t.body!==null?t.body:$t()}function X(t,n,r){throw new x(`Response body does not conform to the specified response body type: '${n}'. The content type of the response is '${t.headers.get("Content-Type")}'. Response status is '${t.status}'. Response source is '${t.headers.get("dynatrace-response-source")}'`,r)}async function Pt(t,n){try{switch(n){case"text":return await kt(t);case"json":return await St(t);case"binary":return await Rt(t);case"form-data":return await Ut(t);case"array-buffer":return await jt(t);case"blob":return await Dt(t)}}catch(r){B(r),X(t,n,r)}}function Vt(t,n){try{return Z(t)}catch(r){B(r),X(t,n,r)}}function It(t,n){switch(n){case"text":case"json":case"binary":case"form-data":case"array-buffer":case"blob":return Pt(t,n);case"readable-stream":return Vt(t,n)}switch(n){case"buffer":case"stream":throw new I(`Unsupported response body type: '${n}'`);default:throw new x(`Invalid body type: '${n}'`)}}function Bt(t,n){return It(t,n)}var z=class{constructor(t,n){this.response=t,this.requestUrl=n?.requestUrl??t.url}requestUrl;get url(){return this.response.url}get status(){return this.response.status}get statusText(){return this.response.statusText}get headers(){let t={};return this.response.headers.forEach((n,r)=>{t[r]=n}),t}body(t="json"){return Bt(this.response.clone(),t)}};function T(t){if(typeof t=="object"&&t!==null&&typeof t.message=="string")return t.message}async function Mt(t){let n;try{n=await t.body("text")}catch(r){let e=`Response body is not available. ${r?.message??"Unknown error occurred."}`;return{message:e.substring(0,100),body:e}}try{let r=JSON.parse(n);return typeof r=="object"&&r!==null?{message:T(r.error)||T(r)||n.substring(0,100),body:r,errorCode:r.error?.details?.errorCode,errorRef:r.error?.details?.errorRef,traceId:r.error?.details?.traceId}:{message:n.substring(0,100),body:n}}catch{return{message:n.substring(0,100),body:n}}}var Nt=async t=>{if(t instanceof tt){let n=t.response.status,{message:r,body:e,errorRef:a,traceId:s,errorCode:o}=await Mt(t.response),h=a?{errorRef:a}:{},m=s?{traceId:s}:{},g=JSON.stringify(e),C=g.length>100?`${g.substring(0,100)}…`:g;return{name:t.name,status:n,message:r,stack:t.stack,type:P.HTTP,details:{url:t.response.url,requestUrl:t.response.requestUrl,method:t.requestMethod,errorCode:o,responseContentType:V(t.response,"content-type"),responseContentLength:V(t.response,"content-length"),responseDtSource:V(t.response,"dynatrace-response-source"),responseBodySample:C},...h,...m}}},V=(t,n)=>{let{headers:r={}}=t,e=Object.keys(r).find(a=>a.toLowerCase()===n.toLowerCase());return e?r[e]:void 0},F=!1;function qt(){!F&&L()&&(F=!0,H(Nt))}var tt=class extends R{name="ResponseError";response;requestMethod;constructor(t,n){qt(),super(`HTTP Error ${t.status}: ${t.statusText}`),this.response=new z(t,{requestUrl:n?.requestUrl??t.url}),this.requestMethod=n?.requestMethod}},Gt=async(t,n)=>{try{return await fetch(t,n)}catch(r){throw B(r),new Et(r)}},Ht=class{_baseUrl;_defaultHeaders;constructor(t){this._baseUrl=t?.baseUrl,this._defaultHeaders=t?.defaultHeaders}_setBaseURL(t){this._baseUrl=t}_setDefaultHeaders(t){this._defaultHeaders=t}async send(t){let{statusValidator:n=ut}=t,r=t.requestBodyType??"json",e=t.body!==void 0?await wt(t.body,r):void 0,a=this._baseUrl?new URL(t.url,this._baseUrl).toString():t.url,s={...this._defaultHeaders,...t?.headers},o=await Gt(a,{method:t.method,headers:mt(s,r),signal:t.abortSignal,body:e});if(n(o.status))return new z(o,{requestUrl:a});throw new tt(o,{requestUrl:a,requestMethod:t.method})}},v=new Ht;var l=class extends Error{constructor(t,n,r){super(n??"ApiClientError: an unexpected error occurred."),this.cause=r,this.name=t}isApiClientError=!0;errorType="JS Error"};function M(t){return t?.isApiClientError===!0&&t instanceof Error}var c=class extends l{isClientRequestError=!0;body;response;constructor(t,n,r,e,a){super(t,e,a),this.errorType="Http Error",this.body=r,this.response=n}};function N(t){return t?.isClientRequestError===!0&&M(t)}var q=class extends c{isApiGatewayError=!0;code;retryAfterSeconds;constructor(t,n){super(n.error.details?.errorCode||"ApiGatewayError",t,n,n.error.message),this.code=n.error.code,this.retryAfterSeconds=n.error.retryAfterSeconds}};var i=class extends l{isInvalidResponseError=!0;responseBody;expectedType;nestedError;response;constructor(t,n,r,e,a,s){super(t,a??`${t}: Response does not match expected datatype${e?" "+e:""}: ${n?.toString()??"unable to deserialize"}`),this.nestedError=n,this.responseBody=r,this.expectedType=e,this.response=s}};function y(t){return t?.isInvalidResponseError===!0&&M(t)}async function A(t){if(t.headers?.["dynatrace-response-source"]==="API Gateway"){let n=await t.body("json");throw new q(t,n)}}var d=class extends c{isErrorEnvelopeError=!0};function Lt(t){try{return JSON.stringify(t)}catch{return String(t)}}function Ot(t){let n=[];return Object.entries(t).forEach(([r,e])=>{if(!e)return;let a=Lt(e);r==="missingScopes"?n.push(`Missing scopes: ${a}`):n.push(`${r}: ${a}`)},[]),n}function u(t,n){let r=t,e=r?.error?.message||n,a=r?.error?.details||{};return[e,...Ot(a)].join(". ")}var Wt={force:!1,datetime:!1};function Kt(t,n){return t?n?`${t}.${n}`:t:n}function et(t,n,r){if(r.has(t))return r.get(t);for(let e of n){let a=Array.isArray(e)?e[0]:e,s=Array.isArray(e)?e[1]:Wt;if(t===a){let b=[a,s];return r.set(t,b),b}let o=0,h=0,m=t.length,g=a.length,C=!0;for(;o<m&&h<g;){let b=t.indexOf(".",o),$=a.indexOf(".",h);b===-1&&(b=m),$===-1&&($=g);let it=t.slice(o,b),D=a.slice(h,$);if(D!=="*"&&D!=="**"&&it!==D){C=!1;break}o=b+1,h=$+1}if(C){if(h<g){let b=a.slice(h);b!=="**"&&b!=="*"&&(C=!1)}o<m&&a.slice(h-1)!=="**"&&(C=!1)}if(C){let b=[a,s];return r.set(t,b),b}}return r.set(t,null),null}var at=(t,n)=>t.startsWith(n)||t.startsWith("*")||t.startsWith("**"),rt=(t,n)=>t.startsWith(n)||t.includes("*")||t.includes("**");function Tt(t,n){let r=n.length;if(!t.includes(".")){for(let s=0;s<r;s++){let o=n[s];if(at(o,t))return!0}return!1}let e=-1,a=0;for(;(e=t.indexOf(".",a))!==-1;){let s=t.slice(0,e),o=!s.includes(".");for(let h=0;h<r;h++){let m=n[h];if(o){if(at(m,s))return!0}else if(rt(m,s))return!0}a=e+1}for(let s=0;s<r;s++){let o=n[s];if(rt(o,t))return!0}return!1}var Ft=/^(\d{4}-\d{2}-\d{2})(T\d{2}:\d{2}:\d{2}(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?)?$/i;function Jt(t){return typeof t=="string"?Ft.test(t):!1}function st(t,n,r){let{force:e,datetime:a}=n;if(r==="to")return e||Jt(t)?new Date(t):t;if(t instanceof Date){let s=t.toISOString();return a?s:s.split("T")[0]}return t}function G(t,n,r,e,a,s=""){if(r.length<=0||!Tt(s,a))return t;if(Array.isArray(t)){let o=et(s,r,e);t.forEach((h,m)=>{typeof h=="object"&&h!==null?G(h,n,r,e,a,s):o&&(t[m]=st(t[m],o[1],n))})}if(typeof t=="object"&&t!==null&&!Array.isArray(t))for(let o of Object.keys(t)){let h=Kt(s,o),m=et(h,r,e);m&&(t[o]=st(t[o],m[1],n)),G(t[o],n,r,e,a,h)}return t}function Yt(t){return t.map(n=>Array.isArray(n)?n[0]:n)}function nt(t,n,r){let e=Yt(r);return G(n,t,r,new Map,e)}function _(t,n){return nt("from",t,n)}function p(t,n){return nt("to",t,n)}var ot=(t,n)=>`${encodeURIComponent(t)}=${encodeURIComponent(typeof n=="number"?n:String(n))}`,Qt=(t,n)=>t[n].map(e=>ot(n,e)).join("&"),Zt=(t,n)=>{let r=encodeURIComponent(n),e=t[n].map(a=>encodeURIComponent(typeof a=="number"?a:String(a))).join(",");return`${r}=${e}`},Xt=(t,n)=>ot(n,t[n]),zt=(t,n,r)=>r?Qt(t,n):Zt(t,n),E=(t,n={})=>{let r=t||{},a=Object.keys(r).filter(s=>typeof r[s]<"u").map(s=>Array.isArray(r[s])?zt(r,s,n.explode?.hasOwnProperty(s)?n.explode[s]:!0):Xt(r,s)).join("&");return a?`?${a}`:""};var te=class{httpClient;shouldTransformDates=!0;constructor(t,n){this.httpClient=t,this.shouldTransformDates=n?.transformDates??!0}async getWorkflows(t={}){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess,id:t.id,isDeployed:t.isDeployed,lastExecution__state__in:t.lastExecutionStateIn,limit:t.limit,modificationInfo__lastModifiedBy:t.modificationInfoLastModifiedBy,offset:t.offset,ordering:t.ordering,owner:t.owner,ownerType:t.ownerType,search:t.search,throttle__isLimitHit:t.throttleIsLimitHit,triggerType:t.triggerType,trigger__schedule__isFaulty:t.triggerScheduleIsFaulty,type:t.type,unacknowledgedSkippedScheduleAt__gte:t.unacknowledgedSkippedScheduleAtGte,unacknowledgedSkippedScheduleAt__lte:t.unacknowledgedSkippedScheduleAtLte},{explode:{lastExecution__state__in:!1,modificationInfo__lastModifiedBy:!1}});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[["results.lastExecution.startedAt",{datetime:!0}],["results.lastExecution.endedAt",{datetime:!0}],["results.trigger.schedule.nextExecution",{datetime:!0}],["results.modificationInfo.createdTime",{datetime:!0}],["results.modificationInfo.lastModifiedTime",{datetime:!0}],["results.throttle.limitEvents.timestamp",{datetime:!0}],["results.workflowLimit.throttle.timestamp",{datetime:!0}],["results.unacknowledgedSkippedScheduleAt",{datetime:!0}]]):e}catch(a){throw new i("WorkflowsClient.getWorkflows:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflows:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async createWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=this.shouldTransformDates?_(t.body,[["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):t.body,r=E({adminAccess:t.adminAccess});try{let e=await this.httpClient.send({url:`/platform/automation/v1/workflows${r}`,method:"POST",requestBodyType:"json",body:n,headers:{"Content-Type":"application/json",Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:s=>[201].includes(s)}),a=await e.body("json");try{return this.shouldTransformDates?p(a,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):a}catch(s){throw new i("WorkflowsClient.createWorkflow:201",s,a,void 0,void 0,e)}}catch(e){if(w(e)||y(e))throw e;if(!f(e))throw new l("UnexpectedError","Unexpected error",e);let a=e.response;if(await A(a),a.status>=400&&a.status<=499){let s=await a.body("json");try{let o=this.shouldTransformDates?p(s,[]):s;throw new d(`${a.status}`,a,o,u(o,""),e)}catch(o){throw o instanceof d?o:new i(`WorkflowsClient.createWorkflow:${a.status}`,o,s,"ErrorEnvelope",void 0,a)}}else try{let s=await a.body("json");throw new c(`${a.status}`,a,s,u(s,`Unexpected api response: code=${a.status} body="${s}"`))}catch(s){if(s instanceof c)throw s;let o=await a.body("text").catch(()=>"");throw new i(`${a.status}`,s,o,"json","Unexpected api response",a)}}}async getWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):e}catch(a){throw new i("WorkflowsClient.getWorkflow:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflow:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async updateWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=this.shouldTransformDates?_(t.body,[["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):t.body,r=E({adminAccess:t.adminAccess});try{let e=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}${r}`,method:"PUT",requestBodyType:"json",body:n,headers:{"Content-Type":"application/json",Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:s=>[200].includes(s)}),a=await e.body("json");try{return this.shouldTransformDates?p(a,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):a}catch(s){throw new i("WorkflowsClient.updateWorkflow:200",s,a,void 0,void 0,e)}}catch(e){if(w(e)||y(e))throw e;if(!f(e))throw new l("UnexpectedError","Unexpected error",e);let a=e.response;if(await A(a),a.status>=400&&a.status<=499){let s=await a.body("json");try{let o=this.shouldTransformDates?p(s,[]):s;throw new d(`${a.status}`,a,o,u(o,""),e)}catch(o){throw o instanceof d?o:new i(`WorkflowsClient.updateWorkflow:${a.status}`,o,s,"ErrorEnvelope",void 0,a)}}else try{let s=await a.body("json");throw new c(`${a.status}`,a,s,u(s,`Unexpected api response: code=${a.status} body="${s}"`))}catch(s){if(s instanceof c)throw s;let o=await a.body("text").catch(()=>"");throw new i(`${a.status}`,s,o,"json","Unexpected api response",a)}}}async deleteWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}${n}`,method:"DELETE",abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:r=>[204].includes(r)});return}catch(r){if(w(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.deleteWorkflow:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async patchWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=this.shouldTransformDates?_(t.body,[["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):t.body,r=E({adminAccess:t.adminAccess});try{let e=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}${r}`,method:"PATCH",requestBodyType:"json",body:n,headers:{"Content-Type":"application/json",Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:s=>[200].includes(s)}),a=await e.body("json");try{return this.shouldTransformDates?p(a,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):a}catch(s){throw new i("WorkflowsClient.patchWorkflow:200",s,a,void 0,void 0,e)}}catch(e){if(w(e)||y(e))throw e;if(!f(e))throw new l("UnexpectedError","Unexpected error",e);let a=e.response;if(await A(a),a.status>=400&&a.status<=499){let s=await a.body("json");try{let o=this.shouldTransformDates?p(s,[]):s;throw new d(`${a.status}`,a,o,u(o,""),e)}catch(o){throw o instanceof d?o:new i(`WorkflowsClient.patchWorkflow:${a.status}`,o,s,"ErrorEnvelope",void 0,a)}}else try{let s=await a.body("json");throw new c(`${a.status}`,a,s,u(s,`Unexpected api response: code=${a.status} body="${s}"`))}catch(s){if(s instanceof c)throw s;let o=await a.body("text").catch(()=>"");throw new i(`${a.status}`,s,o,"json","Unexpected api response",a)}}}async getWorkflowActions(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/actions${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return e}catch(a){throw new i("WorkflowsClient.getWorkflowActions:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflowActions:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async duplicateWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=this.shouldTransformDates?_(t.body,[]):t.body,r=E({adminAccess:t.adminAccess});try{let e=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/duplicate${r}`,method:"POST",requestBodyType:"json",body:n,headers:{"Content-Type":"application/json",Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:s=>[201].includes(s)}),a=await e.body("json");try{return this.shouldTransformDates?p(a,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):a}catch(s){throw new i("WorkflowsClient.duplicateWorkflow:201",s,a,void 0,void 0,e)}}catch(e){if(w(e)||y(e))throw e;if(!f(e))throw new l("UnexpectedError","Unexpected error",e);let a=e.response;if(await A(a),a.status>=400&&a.status<=499){let s=await a.body("json");try{let o=this.shouldTransformDates?p(s,[]):s;throw new d(`${a.status}`,a,o,u(o,""),e)}catch(o){throw o instanceof d?o:new i(`WorkflowsClient.duplicateWorkflow:${a.status}`,o,s,"ErrorEnvelope",void 0,a)}}else try{let s=await a.body("json");throw new c(`${a.status}`,a,s,u(s,`Unexpected api response: code=${a.status} body="${s}"`))}catch(s){if(s instanceof c)throw s;let o=await a.body("text").catch(()=>"");throw new i(`${a.status}`,s,o,"json","Unexpected api response",a)}}}async exportWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/export${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.exportWorkflow:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.exportWorkflow:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async exportWorkflowTemplate(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/template${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.exportWorkflowTemplate:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.exportWorkflowTemplate:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async getWorkflowHistoryRecords(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess,all:t.all});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/history${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[["results.dateCreated",{datetime:!0}]]):e}catch(a){throw new i("WorkflowsClient.getWorkflowHistoryRecords:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflowHistoryRecords:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async getWorkflowHistoryRecord(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/history/${t.version}${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):e}catch(a){throw new i("WorkflowsClient.getWorkflowHistoryRecord:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflowHistoryRecord:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async exportWorkflowHistoryRecord(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/history/${t.version}/export${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[["lastExecution.startedAt",{datetime:!0}],["lastExecution.endedAt",{datetime:!0}],["trigger.schedule.nextExecution",{datetime:!0}],["modificationInfo.createdTime",{datetime:!0}],["modificationInfo.lastModifiedTime",{datetime:!0}],["throttle.limitEvents.timestamp",{datetime:!0}],["workflowLimit.throttle.timestamp",{datetime:!0}],["unacknowledgedSkippedScheduleAt",{datetime:!0}]]):e}catch(a){throw new i("WorkflowsClient.exportWorkflowHistoryRecord:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.exportWorkflowHistoryRecord:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async exportWorkflowHistoryRecordTemplate(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/history/${t.version}/template${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.exportWorkflowHistoryRecordTemplate:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.exportWorkflowHistoryRecordTemplate:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async restoreWorkflowHistoryRecord(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/history/${t.version}/restore${n}`,method:"POST",abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:r=>[200].includes(r)});return}catch(r){if(w(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.restoreWorkflowHistoryRecord:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async resetWorkflowThrottles(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/reset-throttles${n}`,method:"POST",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.resetWorkflowThrottles:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.resetWorkflowThrottles:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async runWorkflow(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=this.shouldTransformDates?_(t.body,[]):t.body,r=E({adminAccess:t.adminAccess,monitor:t.monitor});try{let e=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/run${r}`,method:"POST",requestBodyType:"json",body:n,headers:{"Content-Type":"application/json",Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[201,202].includes(a)});switch(e.status){case 201:{let a=await e.body("json");try{return this.shouldTransformDates?p(a,[["startedAt",{datetime:!0}],["endedAt",{datetime:!0}]]):a}catch(s){throw new i(`WorkflowsClient.runWorkflow:${e.status}`,s,a,void 0,void 0,void 0)}}case 202:{let a=await e.body("json");try{return this.shouldTransformDates?p(a,[["startedAt",{datetime:!0}],["endedAt",{datetime:!0}]]):a}catch(s){throw new i(`WorkflowsClient.runWorkflow:${e.status}`,s,a,void 0,void 0,void 0)}}default:try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}catch(e){if(w(e)||y(e)||N(e))throw e;if(!f(e))throw new l("UnexpectedError","Unexpected error",e);let a=e.response;if(await A(a),a.status>=400&&a.status<=499){let s=await a.body("json");try{let o=this.shouldTransformDates?p(s,[]):s;throw new d(`${a.status}`,a,o,u(o,""),e)}catch(o){throw o instanceof d?o:new i(`WorkflowsClient.runWorkflow:${a.status}`,o,s,"ErrorEnvelope",void 0,a)}}else try{let s=await a.body("json");throw new c(`${a.status}`,a,s,u(s,`Unexpected api response: code=${a.status} body="${s}"`))}catch(s){if(s instanceof c)throw s;let o=await a.body("text").catch(()=>"");throw new i(`${a.status}`,s,o,"json","Unexpected api response",a)}}}async getWorkflowTasks(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.id}/tasks${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.getWorkflowTasks:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflowTasks:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}async getWorkflowTask(t){if(!t)throw new l("API client error","API client call is missing mandatory config parameter");let n=E({adminAccess:t.adminAccess});try{let r=await this.httpClient.send({url:`/platform/automation/v1/workflows/${t.workflowId}/tasks/${t.id}${n}`,method:"GET",headers:{Accept:"application/json"},abortSignal:t instanceof EventTarget?t:t.abortSignal,statusValidator:a=>[200].includes(a)}),e=await r.body("json");try{return this.shouldTransformDates?p(e,[]):e}catch(a){throw new i("WorkflowsClient.getWorkflowTask:200",a,e,void 0,void 0,r)}}catch(r){if(w(r)||y(r))throw r;if(!f(r))throw new l("UnexpectedError","Unexpected error",r);let e=r.response;if(await A(e),e.status>=400&&e.status<=499){let a=await e.body("json");try{let s=this.shouldTransformDates?p(a,[]):a;throw new d(`${e.status}`,e,s,u(s,""),r)}catch(s){throw s instanceof d?s:new i(`WorkflowsClient.getWorkflowTask:${e.status}`,s,a,"ErrorEnvelope",void 0,e)}}else try{let a=await e.body("json");throw new c(`${e.status}`,e,a,u(a,`Unexpected api response: code=${e.status} body="${a}"`))}catch(a){if(a instanceof c)throw a;let s=await e.body("text").catch(()=>"");throw new i(`${e.status}`,a,s,"json","Unexpected api response",e)}}}},U=new te(v);var j={title:"UAM Daily Leaderboard Sender",description:"Sends leaderboard activation data to the API every day at 9am",trigger:{schedule:{trigger:{type:"cron",cron:"0 9 * * *"},timezone:"Asia/Kolkata",isActive:!0}},tasks:{run_leaderboard_sender:{name:"run_leaderboard_sender",description:"Invoke the sendLeaderboardApi app function",action:"dynatrace.automations:run-javascript",input:{script:`import { queryExecutionClient } from '@dynatrace-sdk/client-query';

const buildScorecardStage1_3 = (timeRangeClause: string) => \`
// ============================================================
// COMBINED SCORECARD — Stages 1 + 3
// One row per (user.email × Stage × Category)
// ============================================================

// --- Base: unique users ---
fetch dt.system.events, from: \${timeRangeClause}
| filter isNotNull(user.email)
| summarize user_events = count(), by: { user.email, user.id }
| fieldsAdd join_key = 1

// ============================================================
// STAGE 1 LOOKUP
// ============================================================
| lookup [
    // --- 1. Tenant activation ---
    fetch dt.system.events, from: \${timeRangeClause}
    | filter event.kind == "AUDIT_EVENT" and isNotNull(user.id)
    | summarize first_activity = takeMin(timestamp), users = countDistinctApprox(user.id)
    | fieldsAdd Category = "Tenant activation",
                a1 = true, a2 = isNotNull(first_activity), a3 = isNotNull(first_activity),
                a4 = null, a5 = null

    // --- 2. Deployment ---
    | append [
        fetch dt.entity.host | summarize hosts = countDistinctApprox(id)
        | append [ fetch dt.entity.kubernetes_cluster | summarize clusters = countDistinctApprox(id) ]
        | append [ fetch dt.entity.service | summarize services = countDistinctApprox(id) ]
        | summarize hosts = takeMax(hosts), clusters = takeMax(clusters), services = takeMax(services)
        | fieldsAdd Category = "Deployment",
                    a1 = hosts > 0 or services > 0, a2 = hosts > 0,
                    a3 = clusters > 0, a4 = services > 0, a5 = null
      ]

    // --- 3. AWS integration ---
    | append [
        smartscapeNodes "AWS_*"
        | summarize nodes = count(), regions = countDistinctApprox(aws.region)
        | fieldsAdd Category = "AWS integration",
                    a1 = nodes > 0, a2 = regions > 0, a3 = null, a4 = null, a5 = null
      ]

    // --- 4. AI Observability ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.request.model)
              or isNotNull(gen_ai.provider.name)
        | summarize spans_n = count(), traces = countDistinctApprox(trace.id),
                    models = countDistinctApprox(gen_ai.request.model),
                    providers = countDistinctApprox(gen_ai.provider.name)
        | fieldsAdd Category = "AI Observability",
                    a1 = spans_n > 0, a2 = traces > 0,
                    a3 = models > 0 or providers > 0, a4 = null, a5 = null
      ]

    // --- 5. Application layer ---
    | append [
        fetch user.events, from: \${timeRangeClause} | summarize rum_events = count()
        | summarize rum_events = takeMax(rum_events)
        | fieldsAdd Category = "Application layer",
                    a1 = rum_events > 0, a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- 6. Orchestration layer ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.workflow.name)
              or isNotNull(gen_ai.tool.name)
        | summarize tool_spans = countIf(isNotNull(gen_ai.tool.name)),
                    failures = countIf(span.status_code == "ERROR")
        | fieldsAdd Category = "Orchestration layer",
                    a1 = tool_spans > 0, a2 = failures >= 0, a3 = null, a4 = null, a5 = null
      ]

    // --- 7. Agentic layer ---
    | append [
        fetch spans, from: \${timeRangeClause} | filter isNotNull(gen_ai.agent.name)
        | summarize agents = countDistinctApprox(gen_ai.agent.name),
                    agent_runs = count(),
                    tool_invocations = countIf(isNotNull(gen_ai.tool.name)),
                    completions = countIf(span.status_code != "ERROR")
        | fieldsAdd Category = "Agentic layer",
                    a1 = agents > 0, a2 = agent_runs > 0,
                    a3 = tool_invocations > 0, a4 = completions > 0, a5 = null
      ]

    // --- 8. Model/LLM layer ---
    | append [
        fetch spans, from: \${timeRangeClause} | filter isNotNull(gen_ai.request.model)
        | summarize models = countDistinctApprox(gen_ai.request.model),
                    requests = count(),
                    tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    avg_dur = avg(duration),
                    errors = countIf(span.status_code == "ERROR")
        | fieldsAdd Category = "Model/LLM layer",
                    a1 = models > 0, a2 = requests > 0,
                    a3 = tokens > 0, a4 = isNotNull(avg_dur), a5 = errors >= 0
      ]

    // --- 9. RAG/vector layer ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter gen_ai.operation.name == "embeddings" or isNotNull(gen_ai.data_source.id)
              or isNotNull(db.system)
        | summarize vectors = countDistinctApprox(coalesce(gen_ai.data_source.id, db.system)),
                    retrieval_calls = count(), latency = avg(duration)
        | fieldsAdd Category = "RAG/vector layer",
                    a1 = vectors > 0, a2 = retrieval_calls > 0,
                    a3 = isNotNull(latency), a4 = null, a5 = null
      ]

    // --- 10. Infrastructure ---
    | append [
        fetch spans, from: \${timeRangeClause} | filter isNotNull(gen_ai.usage.input_tokens) | summarize costs = count()
        | summarize costs = takeMax(costs)
        | fieldsAdd Category = "Infrastructure",
                    a1 = costs > 0, a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- 11. Configuration artifacts ---
    | append [
        fetch dt.system.events, from: \${timeRangeClause} | filter event.kind == "AUDIT_EVENT"
        | summarize dashboards = countDistinctApprox(if(dt.app.id == "dynatrace.dashboards"
                                                        and event.type == "POST", resource)),
                    tags = countIf(contains(lower(resource), "tag")),
                    capture = countIf(contains(lower(resource), "capture"))
        | fieldsAdd Category = "Configuration artifacts",
                    a1 = dashboards > 0, a2 = tags > 0,
                    a3 = capture > 0, a4 = null, a5 = null
      ]

    // --- Stage 1 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1, false), 1, else: 0))
                            + toLong(if(coalesce(a2, false), 1, else: 0))
                            + toLong(if(coalesce(a3, false), 1, else: 0))
                            + toLong(if(coalesce(a4, false), 1, else: 0))
                            + toLong(if(coalesce(a5, false), 1, else: 0)),
                items_expected = toLong(if(isNotNull(a1), 1, else: 0))
                               + toLong(if(isNotNull(a2), 1, else: 0))
                               + toLong(if(isNotNull(a3), 1, else: 0))
                               + toLong(if(isNotNull(a4), 1, else: 0))
                               + toLong(if(isNotNull(a5), 1, else: 0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 1,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s1 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s1 }

// ============================================================
// STAGE 3 LOOKUP
// ============================================================
| lookup [
    // --- 1. Reliability ---
    fetch spans, from: \${timeRangeClause}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name)
    | summarize requests = count(), failed_reqs = countIf(span.status_code == "ERROR")
    | append [
        fetch dt.system.events, from: \${timeRangeClause}
        | filter event.kind == "AUDIT_EVENT" and contains(lower(resource), "slo")
        | summarize slo_attainment = count()
      ]
    | summarize requests = takeMax(requests), failed_reqs = takeMax(failed_reqs),
                slo_attainment = takeMax(slo_attainment)
    | fieldsAdd Category = "Reliability",
                a1 = coalesce(requests, 0) > 0,
                a2 = coalesce(failed_reqs, 0) >= 0,
                a3 = false, a4 = false,
                a5 = coalesce(slo_attainment, 0) > 0

    // --- 2. Performance ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.tool.name)
        | summarize avg_duration = avg(duration),
                    model_durations = countIf(isNotNull(gen_ai.request.model)),
                    retrieval_durations = countIf(gen_ai.operation.name == "embeddings"
                                                  or isNotNull(gen_ai.data_source.id))
        | append [
            fetch user.events, from: \${timeRangeClause}
            | filter isNotNull(trace.id) and isNotNull(duration)
            | summarize e2e_response_time = count()
          ]
        | summarize avg_duration = takeMax(avg_duration),
                    model_durations = takeMax(model_durations),
                    retrieval_durations = takeMax(retrieval_durations),
                    e2e_response_time = takeMax(e2e_response_time)
        | fieldsAdd Category = "Performance",
                    a1 = isNotNull(avg_duration), a2 = coalesce(model_durations, 0) > 0,
                    a3 = coalesce(retrieval_durations, 0) > 0,
                    a4 = coalesce(e2e_response_time, 0) > 0, a5 = null
      ]

    // --- 3. Cost ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.usage.input_tokens) or isNotNull(gen_ai.usage.output_tokens)
        | summarize total_tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    conversations = countDistinctApprox(gen_ai.conversation.id)
        | append [
            fetch dt.entity.host
            | summarize host_count = count()
            | fieldsAdd has_infra_util = host_count > 0
          ]
        | summarize total_tokens = takeMax(total_tokens), conversations = takeMax(conversations),
                    has_infra_util = takeMax(has_infra_util)
        | fieldsAdd Category = "Cost",
                    a1 = coalesce(total_tokens, 0) > 0,
                    a2 = coalesce(conversations, 0) > 0 and coalesce(total_tokens, 0) > 0,
                    a3 = coalesce(has_infra_util, false), a4 = null, a5 = null
      ]

    // --- 4. Quality ---
    | append [
        fetch bizevents, from: \${timeRangeClause} | filter event.type == "gen_ai.evaluation.result"
        | summarize relevance = countIf(gen_ai.evaluation.name == "relevance"),
                    grounding = countIf(gen_ai.evaluation.name == "grounding"),
                    toxicity = countIf(gen_ai.evaluation.name == "toxicity"
                                       or gen_ai.evaluation.name == "safety")
        | append [
            fetch spans, from: \${timeRangeClause} | filter isNotNull(feedback.rating)
            | summarize pos_feedback = countIf(feedback.rating > 0),
                        neg_feedback = countIf(feedback.rating < 0)
          ]
        | append [
            fetch spans, from: \${timeRangeClause}
            | filter isNotNull(gen_ai.bedrock.guardrail.activation)
                  or isNotNull(aws.bedrock.guardrail.id)
                  or isNotNull(gen_ai.prompt.prompt_filter_results)
            | summarize guardrails = count()
          ]
        | summarize relevance = takeMax(relevance), grounding = takeMax(grounding),
                    toxicity = takeMax(toxicity), pos_feedback = takeMax(pos_feedback),
                    neg_feedback = takeMax(neg_feedback), guardrails = takeMax(guardrails)
        | fieldsAdd Category = "Quality",
                    a1 = coalesce(relevance, 0) > 0 or coalesce(grounding, 0) > 0,
                    a2 = coalesce(toxicity, 0) > 0,
                    a3 = coalesce(pos_feedback, 0) > 0 or coalesce(neg_feedback, 0) > 0,
                    a4 = coalesce(guardrails, 0) > 0, a5 = null
      ]

    // --- 5. Operations ---
    | append [
        fetch dt.davis.problems, from: \${timeRangeClause} | summarize alerts = countDistinctApprox(display_id)
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "WORKFLOW_EXECUTION"
            | summarize workflow_runs = countDistinctApprox(dt.automation_engine.workflow.id)
          ]
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "ACTION_EXECUTION"
            | filter contains(lower(dt.automation_engine.task.name), "remediat")
                  or contains(lower(dt.automation_engine.task.name), "resolve")
            | summarize remediations = count()
          ]
        | summarize alerts = takeMax(alerts), workflow_runs = takeMax(workflow_runs),
                    remediations = takeMax(remediations)
        | fieldsAdd Category = "Operations",
                    a1 = coalesce(alerts, 0) > 0, a2 = coalesce(workflow_runs, 0) > 0,
                    a3 = coalesce(remediations, 0) > 0, a4 = null, a5 = null
      ]

    // --- 6. Business impact ---
    | append [
        fetch bizevents, from: \${timeRangeClause}
        | filter event.type == "<completion-event>" or event.type == "<transaction-event>"
        | summarize transactions = count()
        | fieldsAdd Category = "Business impact",
                    a1 = coalesce(transactions, 0) > 0,
                    a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- Stage 3 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1, false), 1, else: 0))
                            + toLong(if(coalesce(a2, false), 1, else: 0))
                            + toLong(if(coalesce(a3, false), 1, else: 0))
                            + toLong(if(coalesce(a4, false), 1, else: 0))
                            + toLong(if(coalesce(a5, false), 1, else: 0)),
                items_expected = toLong(if(isNotNull(a1), 1, else: 0))
                               + toLong(if(isNotNull(a2), 1, else: 0))
                               + toLong(if(isNotNull(a3), 1, else: 0))
                               + toLong(if(isNotNull(a4), 1, else: 0))
                               + toLong(if(isNotNull(a5), 1, else: 0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 3,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s3 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s3 }

// ============================================================
// EXPAND STAGES 1 + 3
// ============================================================
| fieldsAdd all_rows = arrayConcat(coalesce(scorecard_s1, array()), coalesce(scorecard_s3, array()))
| fieldsRemove scorecard_s1, scorecard_s3, join_key, user_events
| expand all_rows
| fieldsAdd
    Stage    = all_rows[Stage],
    Date     = all_rows[Date],
    Category = all_rows[Category],
    Status   = all_rows[Status]
| fieldsRemove all_rows
| fields user.email, Stage, Date, Category, Status
| sort user.email asc, Stage asc, Category asc
\`;
const buildScorecardStage2_4 = (timeRangeClause: string) => \`
// ============================================================
// COMBINED SCORECARD — Stages 2 + 4
// One row per (user.email × Stage × Category)
// ============================================================

// --- Base: unique users ---
fetch dt.system.events, from: \${timeRangeClause}
| filter isNotNull(user.email)
| summarize user_events = count(), by: { user.email, user.id }
| fieldsAdd join_key = 1

// ============================================================
// STAGE 2 LOOKUP
// ============================================================
| lookup [
    // --- 1. Model and agent health ---
    fetch spans, from: \${timeRangeClause}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.request.model) or isNotNull(gen_ai.agent.name)
    | summarize requests = count(), errors = countIf(span.status_code == "ERROR"),
                tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                agent_spans = countIf(isNotNull(gen_ai.agent.name)), avg_dur = avg(duration)
    | fieldsAdd Category = "Model and agent health",
                a1 = requests > 0, a2 = isNotNull(avg_dur),
                a3 = requests > 0, a4 = coalesce(tokens,0) > 0, a5 = agent_spans > 0

    // --- 2. SLOs and alerting ---
    | append [
        fetch dt.davis.problems, from: \${timeRangeClause} | summarize problems = countDistinctApprox(event.id)
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "AUDIT_EVENT" and in(event.type, { "POST", "PUT", "PATCH" })
            | filter contains(lower(resource), "slo") or contains(lower(resource), "alerting")
            | summarize slo_config_changes = count()
          ]
        | summarize problems = takeMax(problems), slo_config_changes = takeMax(slo_config_changes)
        | fieldsAdd Category = "SLOs and alerting",
                    a1 = coalesce(slo_config_changes,0) > 0, a2 = coalesce(problems,0) > 0
      ]

    // --- 3. Automation ---
    | append [
        fetch dt.system.events, from: \${timeRangeClause}
        | filter event.kind == "WORKFLOW_EVENT" and event.provider == "AUTOMATION_ENGINE"
        | filter dt.automation_engine.is_draft == false
        | summarize workflows = countDistinctApprox(dt.automation_engine.workflow.id),
                    executions = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state.is_final == true),
                    successes = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state == "SUCCESS"),
                    failures = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state == "ERROR"),
                    retries = sum(dt.automation_engine.action_execution.retry.count)
        | fieldsAdd Category = "Automation",
                    a1 = workflows > 0, a2 = executions > 0,
                    a3 = successes > 0, a4 = coalesce(retries,0) > 0 or failures > 0
      ]

    // --- 4. Topology ---
    | append [
        smartscapeEdges "*" | summarize edges = count()
        | append [
            fetch spans, from: \${timeRangeClause}
            | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
            | summarize agents = countDistinctApprox(gen_ai.agent.name),
                        models = countDistinctApprox(coalesce(gen_ai.response.model, gen_ai.request.model)),
                        tools = countDistinctApprox(gen_ai.tool.name),
                        ai_services = countDistinctApprox(service.name)
          ]
        | summarize edges = takeMax(edges), agents = takeMax(agents),
                    models = takeMax(models), tools = takeMax(tools), ai_services = takeMax(ai_services)
        | fieldsAdd Category = "Topology",
                    a1 = coalesce(ai_services,0) > 0, a2 = coalesce(agents,0) > 0 or coalesce(models,0) > 0,
                    a3 = coalesce(tools,0) > 0, a4 = coalesce(edges,0) > 0
      ]

    // --- 5. Prompt tracing ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
        | summarize traces = countDistinctApprox(trace.id), ai_spans = count(),
                    tool_calls = countIf(isNotNull(gen_ai.tool.name) or gen_ai.operation.name == "execute_tool"),
                    handoff_traces = countDistinctApprox(if(isNotNull(gen_ai.agent.name), trace.id))
        | fieldsAdd Category = "Prompt tracing",
                    a1 = traces > 0, a2 = ai_spans > traces, a3 = handoff_traces > 0, a4 = tool_calls > 0
      ]

    // --- 6. Quality evaluation ---
    | append [
        fetch bizevents, from: \${timeRangeClause} | filter event.type == "gen_ai.evaluation.result"
        | summarize evaluations = count(), evaluators = countDistinctApprox(gen_ai.evaluation.name),
                    labelled = countIf(isNotNull(gen_ai.evaluation.score.label)),
                    linked_traces = countDistinctApprox(trace.id)
        | fieldsAdd Category = "Quality evaluation",
                    a1 = evaluators > 0, a2 = evaluations > 0, a3 = labelled > 0, a4 = linked_traces > 0
      ]

    // --- 7. Governance ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.bedrock.guardrail.activation) or isNotNull(aws.bedrock.guardrail.id)
              or isNotNull(gen_ai.prompt.prompt_filter_results)
        | summarize guardrails = count()
        | append [ fetch dt.system.events, from: \${timeRangeClause} | filter event.kind == "AUDIT_EVENT" | summarize audit_actions = count() ]
        | summarize guardrails = takeMax(guardrails), audit_actions = takeMax(audit_actions)
        | fieldsAdd Category = "Governance",
                    a1 = coalesce(guardrails,0) > 0, a2 = coalesce(audit_actions,0) > 0
      ]

    // --- 8. RUM correlation ---
    | append [
        fetch spans, from: \${timeRangeClause}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name)
        | summarize ai_spans = count(), rum_linked = countIf(isNotNull(dt.rum.session.id))
        | append [ fetch user.events, from: \${timeRangeClause} | filter isNotNull(trace.id) | summarize rum_actions = countIf(isNotNull(useraction.name)) ]
        | summarize ai_spans = takeMax(ai_spans), rum_linked = takeMax(rum_linked), rum_actions = takeMax(rum_actions)
        | fieldsAdd Category = "RUM correlation",
                    a1 = coalesce(rum_actions,0) > 0 and coalesce(rum_linked,0) > 0
      ]

    // --- 9. DQL/notebooks ---
    | append [
        fetch dt.system.events, from: \${timeRangeClause}
        | filter event.kind == "BILLING_USAGE_EVENT" and endsWith(event.type, "- Query")
        | dedup query_id, event.type
        | summarize queries = countDistinctApprox(query_id), notebook_sources = countDistinctApprox(client.source)
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "AUDIT_EVENT" and dt.app.id == "dynatrace.notebooks" and event.type == "POST"
            | summarize notebooks_created = countDistinctApprox(resource)
          ]
        | summarize queries = takeMax(queries), notebook_sources = takeMax(notebook_sources),
                    notebooks_created = takeMax(notebooks_created)
        | fieldsAdd Category = "DQL/notebooks",
                    a1 = coalesce(queries,0) > 0, a2 = coalesce(notebooks_created,0) > 0,
                    a3 = coalesce(notebook_sources,0) > 0
      ]

    // --- 10. Dashboards ---
    | append [
        fetch dt.system.events, from: \${timeRangeClause}
        | filter event.kind == "AUDIT_EVENT" and dt.app.id == "dynatrace.dashboards"
        | summarize dashboards_created = countDistinctApprox(if(event.type == "POST", resource))
        | fieldsAdd Category = "Dashboards", a1 = coalesce(dashboards_created,0) > 0
      ]

    // --- Stage 2 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1,false),1,else:0)) + toLong(if(coalesce(a2,false),1,else:0))
                            + toLong(if(coalesce(a3,false),1,else:0)) + toLong(if(coalesce(a4,false),1,else:0))
                            + toLong(if(coalesce(a5,false),1,else:0)),
                items_expected = toLong(if(isNotNull(a1),1,else:0)) + toLong(if(isNotNull(a2),1,else:0))
                               + toLong(if(isNotNull(a3),1,else:0)) + toLong(if(isNotNull(a4),1,else:0))
                               + toLong(if(isNotNull(a5),1,else:0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 2,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s2 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s2 }

// ============================================================
// STAGE 4 LOOKUP
// ============================================================
| lookup [
    // --- 1. Architecture coverage ---
    fetch spans, from: \${timeRangeClause}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
    | summarize services = countDistinctExact(service.name),
                agents = countDistinctExact(gen_ai.agent.name),
                models = countDistinctExact(coalesce(gen_ai.response.model, gen_ai.request.model)),
                tools = countDistinctExact(gen_ai.tool.name), rum_linked = countIf(isNotNull(dt.rum.session.id))
    | append [ smartscapeEdges "*" | summarize edges = count() ]
    | summarize services = takeMax(services), agents = takeMax(agents), models = takeMax(models),
                tools = takeMax(tools), rum_linked = takeMax(rum_linked), edges = takeMax(edges)
    | fieldsAdd Category = "Architecture coverage",
                a1 = coalesce(edges,0) > 0, a2 = coalesce(services,0) > 0 or coalesce(rum_linked,0) > 0,
                a3 = coalesce(agents,0) > 0 or coalesce(models,0) > 0, a4 = coalesce(tools,0) > 0

    // --- 2. Reliability controls ---
    | append [
        fetch dt.davis.problems, from: \${timeRangeClause} | filter isFalseOrNull(dt.davis.is_duplicate)
        | summarize alerts = countDistinctExact(display_id)
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "WORKFLOW_EXECUTION"
            | filter dt.automation_engine.is_draft == false
            | summarize workflows = countDistinctExact(dt.automation_engine.workflow.id),
                        auto_triggered = countIf(in(dt.automation_engine.workflow_execution.trigger.type, { "Event", "Schedule" }))
          ]
        | append [
            fetch dt.system.events, from: \${timeRangeClause}
            | filter event.kind == "AUDIT_EVENT" and in(event.type, { "POST", "PUT", "PATCH" })
            | filter contains(lower(resource), "slo") | summarize slo_config = count()
          ]
        | summarize alerts = takeMax(alerts), workflows = takeMax(workflows),
                    auto_triggered = takeMax(auto_triggered), slo_config = takeMax(slo_config)
        | fieldsAdd Category = "Reliability controls",
                    a1 = coalesce(slo_config,0) > 0, a2 = coalesce(alerts,0) > 0,
                    a3 = coalesce(workflows,0) > 0 and coalesce(auto_triggered,0) > 0
      ]

    // --- 3. Quality and guardrails ---
    | append [
        fetch bizevents, from: \${timeRangeClause} | filter event.type == "gen_ai.evaluation.result"
        | summarize evaluators = countDistinctExact(gen_ai.evaluation.name),
                    labelled = countIf(isNotNull(gen_ai.evaluation.score.label))
        | append [
            fetch spans, from: \${timeRangeClause}
            | filter isNotNull(gen_ai.bedrock.guardrail.activation) or isNotNull(aws.bedrock.guardrail.id)
                  or isNotNull(gen_ai.prompt.prompt_filter_results)
            | summarize guardrails = count()
          ]
        | summarize evaluators = takeMax(evaluators), labelled = takeMax(labelled), guardrails = takeMax(guardrails)
        | fieldsAdd Category = "Quality and guardrails",
                    a1 = coalesce(evaluators,0) > 0, a2 = coalesce(labelled,0) > 0, a3 = coalesce(guardrails,0) > 0
      ]

    // --- 4. Scale and cost ---
    | append [
        fetch spans, from: \${timeRangeClause} | filter isNotNull(gen_ai.operation.name)
        | summarize tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    active_days = countDistinctExact(bin(timestamp, 1d)),
                    hours = countDistinctExact(bin(timestamp, 1h))
        | summarize tokens = takeMax(tokens), active_days = takeMax(active_days), hours = takeMax(hours)
        | fieldsAdd Category = "Scale and cost",
                    a1 = coalesce(hours,0) >= 24, a2 = coalesce(tokens,0) > 0
      ]

    // --- 5. Evidence history ---
    | append [
        fetch dt.system.events, from: \${timeRangeClause}
        | filter event.kind == "BILLING_USAGE_EVENT" and endsWith(event.type, "- Query")
        | dedup query_id, event.type
        | summarize queries = countDistinctExact(query_id), notebook_sources = countDistinctExact(client.source)
        | summarize queries = takeMax(queries), notebook_sources = takeMax(notebook_sources)
        | fieldsAdd Category = "Evidence history",
                    a1 = coalesce(queries,0) > 0, a2 = coalesce(notebook_sources,0) > 0
      ]

    // --- 6. Executive scorecard ---
    | append [
        fetch spans, from: \${timeRangeClause} | filter isNotNull(gen_ai.operation.name)
        | summarize rel = count(), perf = percentile(duration, 95),
                    cost = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens)
        | append [ fetch bizevents, from: \${timeRangeClause} | filter event.type == "gen_ai.evaluation.result" | summarize quality = count() ]
        | summarize rel = takeMax(rel), perf = takeMax(perf), cost = takeMax(cost), quality = takeMax(quality)
        | fieldsAdd Category = "Executive scorecard",
                    a1 = coalesce(rel,0) > 0, a2 = isNotNull(perf),
                    a3 = coalesce(quality,0) > 0, a4 = coalesce(cost,0) > 0
      ]

    // --- 7. Final showcase ---
    | append [
        data record(Category = "Final showcase")
      ]

    // --- 8. Community contribution ---
    | append [
        fetch bizevents, from: \${timeRangeClause} | filter event.type == "program.community.contribution"
        | summarize contributions = count(), types = countDistinctExact(contribution.type),
                    verified = countIf(contribution.verified_by == "agency")
        | fieldsAdd Category = "Community contribution",
                    a1 = coalesce(contributions,0) > 0, a2 = coalesce(types,0) >= 2, a3 = coalesce(verified,0) > 0
      ]

    // --- Stage 4 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1,false),1,else:0)) + toLong(if(coalesce(a2,false),1,else:0))
                            + toLong(if(coalesce(a3,false),1,else:0)) + toLong(if(coalesce(a4,false),1,else:0)),
                items_expected = toLong(if(isNotNull(a1),1,else:0)) + toLong(if(isNotNull(a2),1,else:0))
                               + toLong(if(isNotNull(a3),1,else:0)) + toLong(if(isNotNull(a4),1,else:0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 4,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s4 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s4 }

// ============================================================
// EXPAND STAGES 2 + 4
// ============================================================
| fieldsAdd all_rows = arrayConcat(coalesce(scorecard_s2, array()), coalesce(scorecard_s4, array()))
| fieldsRemove scorecard_s2, scorecard_s4, join_key, user_events
| expand all_rows
| fieldsAdd
    Stage    = all_rows[Stage],
    Date     = all_rows[Date],
    Category = all_rows[Category],
    Status   = all_rows[Status]
| fieldsRemove all_rows
| fields user.email, Stage, Date, Category, Status
| sort user.email asc, Stage asc, Category asc
\`;

export default async function (payload: any = {}) {
  let effectiveRange = "now() - 24h";
  if (payload.timeframe) {
    if (typeof payload.timeframe === 'string') {
      effectiveRange = payload.timeframe;
    } else if (payload.timeframe.from && payload.timeframe.to) {
      effectiveRange = \`\${payload.timeframe.from} to \${payload.timeframe.to}\`;
    }
  }
  
  const query1_3 = buildScorecardStage1_3(effectiveRange);
  const query2_4 = buildScorecardStage2_4(effectiveRange);

  let allRecords: any[] = [];

  try {
    console.log("Executing scorecard queries...");
    
    // Execute both in parallel
    const [exec13, exec24] = await Promise.all([
      queryExecutionClient.queryExecute({ body: { query: query1_3, requestTimeoutMilliseconds: 60000 } }),
      queryExecutionClient.queryExecute({ body: { query: query2_4, requestTimeoutMilliseconds: 60000 } })
    ]);

    let poll13: any = exec13;
    let poll24: any = exec24;

    while (poll13.state !== 'SUCCEEDED' || poll24.state !== 'SUCCEEDED') {
      const promises: Promise<any>[] = [];
      if (poll13.state !== 'SUCCEEDED') {
        promises.push(queryExecutionClient.queryPoll({ requestToken: exec13.requestToken as string }).then(res => poll13 = res));
      }
      if (poll24.state !== 'SUCCEEDED') {
        promises.push(queryExecutionClient.queryPoll({ requestToken: exec24.requestToken as string }).then(res => poll24 = res));
      }
      await Promise.all(promises);
    }

    const r13 = poll13.result?.records || [];
    const r24 = poll24.result?.records || [];
    allRecords = [...r13, ...r24];
    console.log("Automation compiled " + allRecords.length + " scorecard records.");
  } catch (e: any) {
    console.error("Failed to run DQL query:", e.message);
    return { success: false, error: e.message };
  }

  if (allRecords.length === 0) {
    return { success: false, message: "No records found" };
  }

  const API_URL = 'https://live2.dreamcast.in/dynatrace/api/updateActivity';
  const API_SECRET_KEY = 'fc0fdf8515b2ac3eee8bc6a86527dbd5f2a26c95a52fcd41c7b8820237d189fb';
  
  const results: any[] = [];
  const requestPayloads: any[] = [];
  const skippedRecords: string[] = [];

  for (const rec of allRecords) {
    // Only send COMPLETED activities
    if (rec.Status !== 'COMPLETED') {
      continue;
    }

    let userEmail = rec['user.email'];
    
    if (!userEmail || userEmail === 'unknown' || userEmail === 'unknown@example.com') continue;

    // Ensure email is valid for the API (UUIDs or 'system' cause 422 errors)
    const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    if (!emailRegex.test(userEmail)) {
      // Append a dummy domain to system users/UUIDs so the API accepts them and records the activity
      userEmail = userEmail.replace(/[^a-zA-Z0-9-]/g, '') + "@system.local";
    }

    // Use Date field for createdDate, convert if needed to YYYY-MM-DD HH:MM:SS
    // The query outputs "dd/MM/yyyy h'.'mma", wait, that format is hard to parse in JS.
    // The API recommends: YYYY-MM-DD HH:MM:SS
    // Let's just send the raw date we got, or try to format it?
    let createdDate = rec.Date || new Date().toISOString().slice(0, 19).replace('T', ' ');
    
    // Parse "dd/MM/yyyy h.mma" to "YYYY-MM-DD HH:MM:SS" to satisfy API constraints
    const dateRegex = /^(\\d{2})\\/(\\d{2})\\/(\\d{4}) (\\d{1,2})\\.(\\d{2})(AM|PM)$/i;
    const match = createdDate.match(dateRegex);
    if (match) {
      let [_, dd, mm, yyyy, h, min, ampm] = match;
      let hour = parseInt(h, 10);
      if (ampm.toUpperCase() === 'PM' && hour !== 12) hour += 12;
      if (ampm.toUpperCase() === 'AM' && hour === 12) hour = 0;
      createdDate = \`\${yyyy}-\${mm}-\${dd} \${hour.toString().padStart(2, '0')}:\${min}:00\`;
    }

    
    const category = rec.Category || 'Unknown';
    // Ensure 250 limit
    const safeCategory = category.length > 250 ? category.substring(0, 247) + '...' : category;

    requestPayloads.push({ userEmail, createdDate, category: safeCategory });
  }

  // Process in parallel batches of 15 to avoid 120s timeout
  const BATCH_SIZE = 15;
  for (let i = 0; i < requestPayloads.length; i += BATCH_SIZE) {
    const batch = requestPayloads.slice(i, i + BATCH_SIZE);
    
    await Promise.all(batch.map(async (payload) => {
      const boundary = "----WebKitFormBoundary" + Math.random().toString(36).substring(2);
      let body = "";
      
      const appendField = (key: string, value: string) => {
          body += "--" + boundary + "\\r\\n";
          body += "Content-Disposition: form-data; name=\\"" + key + "\\"\\r\\n\\r\\n";
          body += value + "\\r\\n";
      };

      appendField("email", payload.userEmail);
      appendField("category_name", payload.category);
      appendField("activity_name", payload.category); // Using category for activity_name
      appendField("created_date", payload.createdDate);
      
      body += "--" + boundary + "--\\r\\n";
      
      try {
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Authorization': 'Bearer ' + API_SECRET_KEY,
            'Content-Type': 'multipart/form-data; boundary=' + boundary
          },
          body: body
        });
        
        const resultText = await response.text();
        results.push({
          sent_data_json: {
            email: payload.userEmail,
            category_name: payload.category,
            activity_name: payload.category,
            created_date: payload.createdDate
          },
          api_response_status: response.status,
          api_response_body: resultText
        });
        console.log("Response for " + payload.userEmail + ": " + response.status, resultText);
      } catch (error: any) {
        console.error("Error sending data for " + payload.userEmail + ":", error.message);
        results.push({
          sent_data_json: {
            email: payload.userEmail,
            category_name: payload.category,
            activity_name: payload.category,
            created_date: payload.createdDate
          },
          error: error.message
        });
      }
    }));
    
    // Tiny delay between batches to be nice to API limits
    await new Promise(r => setTimeout(r, 200));
  }
  
  return { 
    success: true, 
    total_valid_sent: results.length,
    total_invalid_skipped: skippedRecords.length,
    sent_details: results,
    skipped_records: [...new Set(skippedRecords)]
  };
}
`},position:{x:0,y:1},conditions:{states:{},custom:"",else:"STOP"},retry:{count:2,delay:5,failedLoopIterationsCount:1},timeout:600,withItems:"",active:!0}},schemaVersion:3,settings:{timezone:"Asia/Kolkata",executionLimit:15,concurrency:1}};async function ze(){try{let n=(await U.getWorkflows()).results?.find(e=>e.title===j.title);return n?.id?(await U.updateWorkflow({id:n.id,body:j}),{success:!0,message:"Workflow updated successfully",id:n.id}):{success:!0,message:"Workflow created successfully",id:(await U.createWorkflow({body:j})).id}}catch(t){return{success:!1,error:t.message}}}export{ze as default};
/*! Bundled license information:

@dynatrace-sdk/error-handlers/esm/index.js:
  (**
   * @license
   * Copyright 2023 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/http-client/esm/index.js:
@dynatrace-sdk/client-automation/esm/index.js:
  (**
   * @license
   * Copyright 2023-2026 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/shared-errors/esm/index.js:
  (**
   * @license
   * Copyright 2023-2025 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
*/
