var De=()=>typeof globalThis<"u"?globalThis:window;function oe(e){let s=ae();typeof s=="function"?s(e):console.warn("Missing addGlobalErrorSerializer function from web runtime.")}function se(){return typeof ae()=="function"}function ae(){return De().dtRuntime?.errorHandlers?.addGlobalErrorSerializer}var G=(e=>(e.COMMON="JS Error",e.HTTP="Http Error",e))(G||{});function P(e){return e?.name==="AbortError"}function U(e){return e?.name==="ResponseError"}var Tt=globalThis.AbortController,St=globalThis.AbortSignal,V=class extends Error{constructor(e,s){super(e),this.cause=s}},K=class extends V{name="UnsupportedOperationError";constructor(e,s){super(e,s)}};function Re(e,s){let a=new Response(e);switch(s){case"text":return a.text();case"json":return a.json();case"array-buffer":return a.arrayBuffer();case"blob":return a.blob();case"readable-stream":return a.body}throw new K(`Unsupported binary type: ${s}.`)}var L=class ${constructor(s){this.data=s}static fromText(s){return new $(new Blob([s]))}static fromJson(s){return new $(new Blob([JSON.stringify(s)]))}static from(s){if(s instanceof Blob||s instanceof ArrayBuffer||s instanceof ReadableStream)return new $(s);throw new K("Unsupported binary type.")}get(s){return Re(this.data,s)}};function ue(e){return typeof e.get=="function"}var x=class extends V{name="DataTypeError";constructor(e,s){super(e,s)}},Ie=e=>200<=e&&e<300;function de(e){return String(e)}function fe(e){return JSON.stringify(e)}async function Me(e){if(e instanceof ArrayBuffer||e instanceof Blob)return e;if(e instanceof ReadableStream)return new Response(e).arrayBuffer();if(ue(e))return e.get("array-buffer");throw new x("Cannot encode form data field as binary type.")}async function Be(e){let s=new FormData;for(let a of e)switch(a.type){case"text":s.append(a.name,de(a.value));break;case"json":s.append(a.name,new Blob([fe(a.value)],{type:a.contentType??"application/json"}),a.filename??"json");break;case"binary":{if(File&&a.value instanceof File){let n=a.value;s.append(a.name,new File([n],a.filename??n.name,{type:a.contentType??n.type??"application/octet-stream",lastModified:n.lastModified}),a.filename??n.name)}else{let n="type"in a.value?a.value.type:void 0;s.append(a.name,new Blob([await Me(a.value)],{type:a.contentType??n??"application/octet-stream"}),a.filename??"binary")}break}}return s}async function ke(e){if(e instanceof Blob||e instanceof ArrayBuffer||e instanceof ReadableStream)return e;if(ue(e))try{return await e.get("array-buffer")}catch(s){throw new x("Cannot encode body as binary type.",s)}else throw new x("Cannot encode body as binary type.")}async function Oe(e,s){switch(s){case"text":return de(e);case"json":return fe(e);case"form-data":return await Be(e);case"binary":return await ke(e)}throw new x(`Invalid body type: '${s}'`)}function Pe(e){switch(e){case"json":return"application/json";case"text":return"text/plain";case"binary":return"application/octet-stream"}throw new x(`Invalid body type: '${e}'`)}function Ue(e){if(e["Content-Type"]?.startsWith("multipart/")){let{"Content-Type":s,...a}=e;return a}return e}function je(e,s){let a=e?Ue(e):void 0;return!Object.keys(a??{}).some(o=>o.toLowerCase()==="content-type")&&s!=="form-data"?{"content-type":Pe(s),...a}:a}var Le=class extends Error{constructor(e){super(typeof e?.message=="string"?`Request aborted: ${e.message}`:"Request aborted."),this.cause=e}name="AbortError"},W=e=>{if(e instanceof Error&&e.name==="AbortError")throw new Le(e)},$e=class extends V{constructor(e){super(typeof e?.message=="string"?`Request failed: ${e.message}`:"Request failed."),this.cause=e}name="RequestError"};function ne(e){if(e!==void 0)return String.fromCharCode(e)}function Ve(e){return["application/json","text/plain"].includes(String(e).toLowerCase())}function ie(e){return e&&JSON.parse(`"${e}"`)}function ze(e){let s=ie(/form-data;.*filename="((?:[^"\\]|\\.)*)"/gm.exec(e)?.[1]);return{name:ie(/form-data;.*(?<!file)name="((?:[^"\\]|\\.)*)"/gm.exec(e)?.[1]),fileName:s}}function Qe(e){return/multipart\/form-data;boundary=(.*)/gm.exec(e)?.[1]}var He=class{constructor(e,s){this.sourceArray=e,this.boundary=s}currentChar=null;currentByte=null;offset=0;utf8Decoder=new TextDecoder("utf-8");get previousByte(){return this.sourceArray[this.offset-2]}get previousChar(){return ne(this.previousByte)}next(){return this.offset>=this.sourceArray.byteLength?(this.currentChar=null,this.currentByte=null,!1):(this.currentByte=this.sourceArray[this.offset],this.currentChar=String.fromCharCode(this.currentByte),this.offset++,!0)}charAt(e){return ne(this.sourceArray[e])??null}nextChar(){return this.next(),this.currentChar}nextByte(){return this.next(),this.currentByte}get nextTwoChars(){return String.fromCharCode(this.sourceArray[this.offset],this.sourceArray[this.offset+1])}findNextBoundaryOffset(e=this.offset){let s=0,a=!1,n=e,o=this.charAt(n);for(;!a;){if(o===null)return null;o===this.boundary[s]?(s++,s===this.boundary.length&&(a=!0)):s=0,n++,o=this.charAt(n)}return n-this.boundary.length}skipPastNextBoundary(){let e=this.findNextBoundaryOffset();if(e===null)return!1;this.offset=e+this.boundary.length,this.currentByte=this.sourceArray[this.offset],this.currentChar=String.fromCharCode(this.currentByte);let s=this.nextTwoChars;return s=="--"?!1:(s==`\r
`&&(this.offset++,this.next()),!0)}readLine(){let e=[];do{let s=this.nextByte();if(s===null)return null;e.push(s)}while(this.currentChar!==null&&this.currentChar!==`
`&&this.previousChar!=="\r");return Uint8Array.from(e)}readSectionHeaders(){let e={},s=this.offset,a=!1;for(;!a;){let o=this.readLine();if(o===null)throw TypeError("Unexpected end of response while parsing headers");let r=this.utf8Decoder.decode(o);if(r===`\r
`){a=!0;break}let[t,i]=r.split(":").map(f=>(f??"").trim());e[t.toLowerCase()]=i}return{headersLength:this.offset-s,headers:e}}extractData(){let e=this.findNextBoundaryOffset()??this.sourceArray.length,a=String.fromCharCode(this.sourceArray[e-2],this.sourceArray[e-1])===`\r
`?e-2:e,n=this.sourceArray.slice(this.offset,a);return{payloadStartOffset:this.offset,payloadEndOffset:a,data:n}}parse(){let e=[];for(;this.skipPastNextBoundary();){let s=this.offset,{headers:a}=this.readSectionHeaders(),{data:n,payloadStartOffset:o,payloadEndOffset:r}=this.extractData(),t=Ve(a["content-type"]),{name:i,fileName:f}=ze(a["content-disposition"]);e.push({name:i,text:t?this.utf8Decoder.decode(n):void 0,file:t?void 0:new File([n],f??"",{type:a["content-type"]??"application/octet-stream"}),rawData:n,headers:a,headersStartOffset:s,payloadStartOffset:o,payloadEndOffset:r})}return e}};function Ge(){return/apple/i.test(navigator.vendor)}function Fe(e,s){return new He(e,s).parse()}function Ke(){return new ReadableStream({start(e){e.close()}})}async function We(e){return e.body!==null?e.text():""}async function Je(e){return e.body!==null?e.json():null}async function Xe(e){return L.from(pe(e))}async function Ye(e){if(e.body===null)return[];{let s=[];if(Ge()){let a=await e.clone(),n=new Uint8Array(await a.arrayBuffer()),o=Qe(a.headers.get("content-type")),r=Fe(n,`--${o}`);(await e.formData()).forEach((i,f)=>{let E=r.find(({name:v})=>v===f);typeof i=="string"&&E?.file!==void 0?s.push({type:"binary",name:f,contentType:E.headers["content-type"],filename:E.file.name,value:L.from(E.file)}):i instanceof File?s.push({type:"binary",name:f,contentType:i.type,filename:i.name,value:L.from(i)}):s.push({type:"text",name:f,value:i})})}else(await e.formData()).forEach((n,o)=>{n instanceof File?s.push({type:"binary",name:o,contentType:n.type,filename:n.name,value:L.from(n)}):s.push({type:"text",name:o,value:n})});return s}}async function Ze(e){return e!==null?e.arrayBuffer():new ArrayBuffer(0)}async function et(e){return e!==null?e.blob():new Blob}function pe(e){return e.body!==null?e.body:Ke()}function he(e,s,a){throw new x(`Response body does not conform to the specified response body type: '${s}'. The content type of the response is '${e.headers.get("Content-Type")}'. Response status is '${e.status}'. Response source is '${e.headers.get("dynatrace-response-source")}'`,a)}async function tt(e,s){try{switch(s){case"text":return await We(e);case"json":return await Je(e);case"binary":return await Xe(e);case"form-data":return await Ye(e);case"array-buffer":return await Ze(e);case"blob":return await et(e)}}catch(a){W(a),he(e,s,a)}}function rt(e,s){try{return pe(e)}catch(a){W(a),he(e,s,a)}}function ot(e,s){switch(s){case"text":case"json":case"binary":case"form-data":case"array-buffer":case"blob":return tt(e,s);case"readable-stream":return rt(e,s)}switch(s){case"buffer":case"stream":throw new K(`Unsupported response body type: '${s}'`);default:throw new x(`Invalid body type: '${s}'`)}}function st(e,s){return ot(e,s)}var me=class{constructor(e,s){this.response=e,this.requestUrl=s?.requestUrl??e.url}requestUrl;get url(){return this.response.url}get status(){return this.response.status}get statusText(){return this.response.statusText}get headers(){let e={};return this.response.headers.forEach((s,a)=>{e[a]=s}),e}body(e="json"){return st(this.response.clone(),e)}};function ce(e){if(typeof e=="object"&&e!==null&&typeof e.message=="string")return e.message}async function at(e){let s;try{s=await e.body("text")}catch(a){let n=`Response body is not available. ${a?.message??"Unknown error occurred."}`;return{message:n.substring(0,100),body:n}}try{let a=JSON.parse(s);return typeof a=="object"&&a!==null?{message:ce(a.error)||ce(a)||s.substring(0,100),body:a,errorCode:a.error?.details?.errorCode,errorRef:a.error?.details?.errorRef,traceId:a.error?.details?.traceId}:{message:s.substring(0,100),body:s}}catch{return{message:s.substring(0,100),body:s}}}var nt=async e=>{if(e instanceof ye){let s=e.response.status,{message:a,body:n,errorRef:o,traceId:r,errorCode:t}=await at(e.response),i=o?{errorRef:o}:{},f=r?{traceId:r}:{},E=JSON.stringify(n),v=E.length>100?`${E.substring(0,100)}…`:E;return{name:e.name,status:s,message:a,stack:e.stack,type:G.HTTP,details:{url:e.response.url,requestUrl:e.response.requestUrl,method:e.requestMethod,errorCode:t,responseContentType:F(e.response,"content-type"),responseContentLength:F(e.response,"content-length"),responseDtSource:F(e.response,"dynatrace-response-source"),responseBodySample:v},...i,...f}}},F=(e,s)=>{let{headers:a={}}=e,n=Object.keys(a).find(o=>o.toLowerCase()===s.toLowerCase());return n?a[n]:void 0},le=!1;function it(){!le&&se()&&(le=!0,oe(nt))}var ye=class extends V{name="ResponseError";response;requestMethod;constructor(e,s){it(),super(`HTTP Error ${e.status}: ${e.statusText}`),this.response=new me(e,{requestUrl:s?.requestUrl??e.url}),this.requestMethod=s?.requestMethod}},ct=async(e,s)=>{try{return await fetch(e,s)}catch(a){throw W(a),new $e(a)}},lt=class{_baseUrl;_defaultHeaders;constructor(e){this._baseUrl=e?.baseUrl,this._defaultHeaders=e?.defaultHeaders}_setBaseURL(e){this._baseUrl=e}_setDefaultHeaders(e){this._defaultHeaders=e}async send(e){let{statusValidator:s=Ie}=e,a=e.requestBodyType??"json",n=e.body!==void 0?await Oe(e.body,a):void 0,o=this._baseUrl?new URL(e.url,this._baseUrl).toString():e.url,r={...this._defaultHeaders,...e?.headers},t=await ct(o,{method:e.method,headers:je(r,a),signal:e.abortSignal,body:n});if(s(t.status))return new me(t,{requestUrl:o});throw new ye(t,{requestUrl:o,requestMethod:e.method})}},J=new lt;var _=class extends Error{constructor(e,s,a){super(s??"ApiClientError: an unexpected error occurred."),this.cause=a,this.name=e}isApiClientError=!0;errorType="JS Error"};function X(e){return e?.isApiClientError===!0&&e instanceof Error}var w=class extends _{isClientRequestError=!0;body;response;constructor(e,s,a,n,o){super(e,n,o),this.errorType="Http Error",this.body=a,this.response=s}};function z(e){return e?.isClientRequestError===!0&&X(e)}var Y=class extends w{isApiGatewayError=!0;code;retryAfterSeconds;constructor(e,s){super(s.error.details?.errorCode||"ApiGatewayError",e,s,s.error.message),this.code=s.error.code,this.retryAfterSeconds=s.error.retryAfterSeconds}};var c=class extends _{isInvalidResponseError=!0;responseBody;expectedType;nestedError;response;constructor(e,s,a,n,o,r){super(e,o??`${e}: Response does not match expected datatype${n?" "+n:""}: ${s?.toString()??"unable to deserialize"}`),this.nestedError=s,this.responseBody=a,this.expectedType=n,this.response=r}};function N(e){return e?.isInvalidResponseError===!0&&X(e)}async function Z(e){if(e.headers?.["dynatrace-response-source"]==="API Gateway"){let s=await e.body("json");throw new Y(e,s)}}var g=class extends w{isErrorEnvelopeError=!0};function ut(e){try{return JSON.stringify(e)}catch{return String(e)}}function dt(e){let s=[];return Object.entries(e).forEach(([a,n])=>{if(!n)return;let o=ut(n);a==="missingScopes"?s.push(`Missing scopes: ${o}`):s.push(`${a}: ${o}`)},[]),s}function l(e,s){let a=e,n=a?.error?.message||s,o=a?.error?.details||{};return[n,...dt(o)].join(". ")}var q=class extends g{isBadRequest=!0;name="BadRequest"};var T=class extends g{isGatewayTimeout=!0;name="GatewayTimeout"};var S=class extends g{isInsufficientPermission=!0;name="InsufficientPermission"};var D=class extends g{isInternalServerError=!0;name="InternalServerError"};var R=class extends g{isMethodNotAllowed=!0;name="MethodNotAllowed"};var I=class extends g{isServiceUnavailable=!0;name="ServiceUnavailable"};var we=class extends g{isTenantNotFound=!0;name="TenantNotFound"};var M=class extends g{isUnauthorized=!0;name="Unauthorized"};var B=class extends g{isUnsupportedMediaType=!0;name="UnsupportedMediaType"};var ft={force:!1,datetime:!1};function pt(e,s){return e?s?`${e}.${s}`:e:s}function Ee(e,s,a){if(a.has(e))return a.get(e);for(let n of s){let o=Array.isArray(n)?n[0]:n,r=Array.isArray(n)?n[1]:ft;if(e===o){let d=[o,r];return a.set(e,d),d}let t=0,i=0,f=e.length,E=o.length,v=!0;for(;t<f&&i<E;){let d=e.indexOf(".",t),h=o.indexOf(".",i);d===-1&&(d=f),h===-1&&(h=E);let p=e.slice(t,d),m=o.slice(i,h);if(m!=="*"&&m!=="**"&&p!==m){v=!1;break}t=d+1,i=h+1}if(v){if(i<E){let d=o.slice(i);d!=="**"&&d!=="*"&&(v=!1)}t<f&&o.slice(i-1)!=="**"&&(v=!1)}if(v){let d=[o,r];return a.set(e,d),d}}return a.set(e,null),null}var ge=(e,s)=>e.startsWith(s)||e.startsWith("*")||e.startsWith("**"),ve=(e,s)=>e.startsWith(s)||e.includes("*")||e.includes("**");function ht(e,s){let a=s.length;if(!e.includes(".")){for(let r=0;r<a;r++){let t=s[r];if(ge(t,e))return!0}return!1}let n=-1,o=0;for(;(n=e.indexOf(".",o))!==-1;){let r=e.slice(0,n),t=!r.includes(".");for(let i=0;i<a;i++){let f=s[i];if(t){if(ge(f,r))return!0}else if(ve(f,r))return!0}o=n+1}for(let r=0;r<a;r++){let t=s[r];if(ve(t,e))return!0}return!1}var mt=/^(\d{4}-\d{2}-\d{2})(T\d{2}:\d{2}:\d{2}(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?)?$/i;function yt(e){return typeof e=="string"?mt.test(e):!1}function _e(e,s,a){let{force:n,datetime:o}=s;if(a==="to")return n||yt(e)?new Date(e):e;if(e instanceof Date){let r=e.toISOString();return o?r:r.split("T")[0]}return e}function te(e,s,a,n,o,r=""){if(a.length<=0||!ht(r,o))return e;if(Array.isArray(e)){let t=Ee(r,a,n);e.forEach((i,f)=>{typeof i=="object"&&i!==null?te(i,s,a,n,o,r):t&&(e[f]=_e(e[f],t[1],s))})}if(typeof e=="object"&&e!==null&&!Array.isArray(e))for(let t of Object.keys(e)){let i=pt(r,t),f=Ee(i,a,n);f&&(e[t]=_e(e[t],f[1],s)),te(e[t],s,a,n,o,i)}return e}function wt(e){return e.map(s=>Array.isArray(s)?s[0]:s)}function be(e,s,a){let n=wt(a);return te(s,e,a,new Map,n)}function Et(e,s){return be("from",e,s)}function u(e,s){return be("to",e,s)}var Ae=class extends g{isConflict=!0;name="Conflict"};var Q=class extends g{isQueryGone=!0;name="QueryGone"};var H=class extends g{isQueryNotFound=!0;name="QueryNotFound"};var k=class extends g{isTooManyRequests=!0;name="TooManyRequests"};var Ce=(e,s)=>`${encodeURIComponent(e)}=${encodeURIComponent(typeof s=="number"?s:String(s))}`,gt=(e,s)=>e[s].map(n=>Ce(s,n)).join("&"),vt=(e,s)=>{let a=encodeURIComponent(s),n=e[s].map(o=>encodeURIComponent(typeof o=="number"?o:String(o))).join(",");return`${a}=${n}`},_t=(e,s)=>Ce(s,e[s]),At=(e,s,a)=>a?gt(e,s):vt(e,s),ee=(e,s={})=>{let a=e||{},o=Object.keys(a).filter(r=>typeof a[r]<"u").map(r=>Array.isArray(a[r])?At(a,r,s.explode?.hasOwnProperty(r)?s.explode[r]:!0):_t(a,r)).join("&");return o?`?${o}`:""},bt=class{httpClient;shouldTransformDates=!0;constructor(e,s){this.httpClient=e,this.shouldTransformDates=s?.transformDates??!0}async queryCancel(e){if(!e)throw new _("API client error","API client call is missing mandatory config parameter");let s=ee({"request-token":e.requestToken,enrich:e.enrich},{explode:{"request-token":!1}}),a={...e.dtClientContext!==void 0&&{"dt-client-context":String(e.dtClientContext)}};try{let n=await this.httpClient.send({url:`/platform/storage/query/v1/query:cancel${s}`,method:"POST",headers:{Accept:"application/json",...a},abortSignal:e instanceof EventTarget?e:e.abortSignal,statusValidator:o=>[200,202].includes(o)});switch(n.status){case 200:{let o=await n.body("json");try{return this.shouldTransformDates?u(o,[["result.metadata.grail.analysisTimeframe.end",{datetime:!0}],["result.metadata.grail.analysisTimeframe.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}],["result.records.**.end",{datetime:!0}],["result.records.**.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}]]):o}catch(r){throw new c(`QueryExecutionClient.query:cancel:${n.status}`,r,o,void 0,void 0,void 0)}}case 202:return;default:try{let o=await n.body("json");throw new w(`${n.status}`,n,o,l(o,`Unexpected api response: code=${n.status} body="${o}"`))}catch(o){if(o instanceof w)throw o;let r=await n.body("text").catch(()=>"");throw new c(`${n.status}`,o,r,"json","Unexpected api response",n)}}}catch(n){if(P(n)||N(n)||z(n))throw n;if(!U(n))throw new _("UnexpectedError","Unexpected error",n);let o=n.response;switch(await Z(o),o.status){case 400:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new q("400",o,t,l(t,"The supplied request is wrong. Either the query itself or other parameters are wrong."),n)}catch(t){throw t instanceof q?t:new c("QueryExecutionClient.query:cancel:400",t,r,"ErrorEnvelope",void 0,o)}}case 401:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new M("401",o,t,l(t,"Unauthorized. The request lacks valid authentication credentials. Happens when the authentication token is missing or invalid."),n)}catch(t){throw t instanceof M?t:new c("QueryExecutionClient.query:cancel:401",t,r,"ErrorEnvelope",void 0,o)}}case 403:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new S("403",o,t,l(t,"Insufficient permissions."),n)}catch(t){throw t instanceof S?t:new c("QueryExecutionClient.query:cancel:403",t,r,"ErrorEnvelope",void 0,o)}}case 404:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new H("404",o,t,l(t,"Not Found - The query with the given ID does not exist for this tenant."),n)}catch(t){throw t instanceof H?t:new c("QueryExecutionClient.query:cancel:404",t,r,"ErrorEnvelope",void 0,o)}}case 405:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new R("405",o,t,l(t,"Method not allowed. The HTTP method is not supported for this endpoint."),n)}catch(t){throw t instanceof R?t:new c("QueryExecutionClient.query:cancel:405",t,r,"ErrorEnvelope",void 0,o)}}case 410:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new Q("410",o,t,l(t,"The query for the given request-token is not available anymore."),n)}catch(t){throw t instanceof Q?t:new c("QueryExecutionClient.query:cancel:410",t,r,"ErrorEnvelope",void 0,o)}}case 415:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new B("415",o,t,l(t,"Unsupported media type. The request content type is not supported."),n)}catch(t){throw t instanceof B?t:new c("QueryExecutionClient.query:cancel:415",t,r,"ErrorEnvelope",void 0,o)}}case 429:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new k("429",o,t,l(t,"Too Many Requests - There were too many queries in the queue."),n)}catch(t){throw t instanceof k?t:new c("QueryExecutionClient.query:cancel:429",t,r,"ErrorEnvelope",void 0,o)}}case 500:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new D("500",o,t,l(t,"An internal server error has occurred."),n)}catch(t){throw t instanceof D?t:new c("QueryExecutionClient.query:cancel:500",t,r,"ErrorEnvelope",void 0,o)}}case 503:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new I("503",o,t,l(t,"Service Unavailable - The grail instance is either shutting down or busy."),n)}catch(t){throw t instanceof I?t:new c("QueryExecutionClient.query:cancel:503",t,r,"ErrorEnvelope",void 0,o)}}case 504:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new T("504",o,t,l(t,"Gateway timeout. The service did not respond in time."),n)}catch(t){throw t instanceof T?t:new c("QueryExecutionClient.query:cancel:504",t,r,"ErrorEnvelope",void 0,o)}}default:try{let r=await o.body("json");throw new w(`${o.status}`,o,r,l(r,`Unexpected api response: code=${o.status} body="${r}"`),n)}catch(r){if(r instanceof w)throw r;let t=await o.body("text").catch(()=>"");throw new c(`${o.status}`,r,t,"json","Unexpected api response",o)}}}}async queryExecute(e){if(!e)throw new _("API client error","API client call is missing mandatory config parameter");let s=this.shouldTransformDates?Et(e.body,[]):e.body,a=ee({enrich:e.enrich}),n={...e.dtClientContext!==void 0&&{"dt-client-context":String(e.dtClientContext)}};try{let o=await this.httpClient.send({url:`/platform/storage/query/v1/query:execute${a}`,method:"POST",requestBodyType:"json",body:s,headers:{"Content-Type":"application/json",Accept:"application/json",...n},abortSignal:e instanceof EventTarget?e:e.abortSignal,statusValidator:r=>[200,202].includes(r)});switch(o.status){case 200:{let r=await o.body("json");try{return this.shouldTransformDates?u(r,[["result.metadata.grail.analysisTimeframe.end",{datetime:!0}],["result.metadata.grail.analysisTimeframe.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}],["result.records.**.end",{datetime:!0}],["result.records.**.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}]]):r}catch(t){throw new c(`QueryExecutionClient.query:execute:${o.status}`,t,r,void 0,void 0,void 0)}}case 202:{let r=await o.body("json");try{return this.shouldTransformDates?u(r,[["result.metadata.grail.analysisTimeframe.end",{datetime:!0}],["result.metadata.grail.analysisTimeframe.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}],["result.records.**.end",{datetime:!0}],["result.records.**.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}]]):r}catch(t){throw new c(`QueryExecutionClient.query:execute:${o.status}`,t,r,void 0,void 0,void 0)}}default:try{let r=await o.body("json");throw new w(`${o.status}`,o,r,l(r,`Unexpected api response: code=${o.status} body="${r}"`))}catch(r){if(r instanceof w)throw r;let t=await o.body("text").catch(()=>"");throw new c(`${o.status}`,r,t,"json","Unexpected api response",o)}}}catch(o){if(P(o)||N(o)||z(o))throw o;if(!U(o))throw new _("UnexpectedError","Unexpected error",o);let r=o.response;switch(await Z(r),r.status){case 400:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new q("400",r,i,l(i,"The supplied request is wrong. Either the query itself or other parameters are wrong."),o)}catch(i){throw i instanceof q?i:new c("QueryExecutionClient.query:execute:400",i,t,"ErrorEnvelope",void 0,r)}}case 401:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new M("401",r,i,l(i,"Unauthorized. The request lacks valid authentication credentials. Happens when the authentication token is missing or invalid."),o)}catch(i){throw i instanceof M?i:new c("QueryExecutionClient.query:execute:401",i,t,"ErrorEnvelope",void 0,r)}}case 403:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new S("403",r,i,l(i,"Insufficient permissions."),o)}catch(i){throw i instanceof S?i:new c("QueryExecutionClient.query:execute:403",i,t,"ErrorEnvelope",void 0,r)}}case 404:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new we("404",r,i,l(i,"Not Found - Returned when the tenant is inactive or not found."),o)}catch(i){throw i instanceof we?i:new c("QueryExecutionClient.query:execute:404",i,t,"ErrorEnvelope",void 0,r)}}case 405:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new R("405",r,i,l(i,"Method not allowed. The HTTP method is not supported for this endpoint."),o)}catch(i){throw i instanceof R?i:new c("QueryExecutionClient.query:execute:405",i,t,"ErrorEnvelope",void 0,r)}}case 409:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new Ae("409",r,i,l(i,"Conflict - The supplied queryId already exists and is currently running."),o)}catch(i){throw i instanceof Ae?i:new c("QueryExecutionClient.query:execute:409",i,t,"ErrorEnvelope",void 0,r)}}case 415:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new B("415",r,i,l(i,"Unsupported media type. The request content type is not supported."),o)}catch(i){throw i instanceof B?i:new c("QueryExecutionClient.query:execute:415",i,t,"ErrorEnvelope",void 0,r)}}case 429:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new k("429",r,i,l(i,"Too Many Requests - There were too many queries in the queue."),o)}catch(i){throw i instanceof k?i:new c("QueryExecutionClient.query:execute:429",i,t,"ErrorEnvelope",void 0,r)}}case 500:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new D("500",r,i,l(i,"An internal server error has occurred."),o)}catch(i){throw i instanceof D?i:new c("QueryExecutionClient.query:execute:500",i,t,"ErrorEnvelope",void 0,r)}}case 503:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new I("503",r,i,l(i,"Service Unavailable - The grail instance is either shutting down or busy."),o)}catch(i){throw i instanceof I?i:new c("QueryExecutionClient.query:execute:503",i,t,"ErrorEnvelope",void 0,r)}}case 504:{let t=await r.body("json");try{let i=this.shouldTransformDates?u(t,[]):t;throw new T("504",r,i,l(i,"Gateway timeout. The service did not respond in time."),o)}catch(i){throw i instanceof T?i:new c("QueryExecutionClient.query:execute:504",i,t,"ErrorEnvelope",void 0,r)}}default:try{let t=await r.body("json");throw new w(`${r.status}`,r,t,l(t,`Unexpected api response: code=${r.status} body="${t}"`),o)}catch(t){if(t instanceof w)throw t;let i=await r.body("text").catch(()=>"");throw new c(`${r.status}`,t,i,"json","Unexpected api response",r)}}}}async queryPoll(e){if(!e)throw new _("API client error","API client call is missing mandatory config parameter");let s=ee({"request-token":e.requestToken,"request-timeout-milliseconds":e.requestTimeoutMilliseconds,enrich:e.enrich},{explode:{"request-token":!1,"request-timeout-milliseconds":!1}}),a={...e.dtClientContext!==void 0&&{"dt-client-context":String(e.dtClientContext)}};try{let n=await this.httpClient.send({url:`/platform/storage/query/v1/query:poll${s}`,method:"GET",headers:{Accept:"application/json",...a},abortSignal:e instanceof EventTarget?e:e.abortSignal,statusValidator:r=>[200].includes(r)}),o=await n.body("json");try{return this.shouldTransformDates?u(o,[["result.metadata.grail.analysisTimeframe.end",{datetime:!0}],["result.metadata.grail.analysisTimeframe.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}],["result.records.**.end",{datetime:!0}],["result.records.**.start",{datetime:!0}],["result.records.*.end",{datetime:!0}],["result.records.*.start",{datetime:!0}]]):o}catch(r){throw new c("QueryExecutionClient.query:poll:200",r,o,void 0,void 0,n)}}catch(n){if(P(n)||N(n))throw n;if(!U(n))throw new _("UnexpectedError","Unexpected error",n);let o=n.response;switch(await Z(o),o.status){case 400:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new q("400",o,t,l(t,"The supplied request is wrong. Either the query itself or other parameters are wrong."),n)}catch(t){throw t instanceof q?t:new c("QueryExecutionClient.query:poll:400",t,r,"ErrorEnvelope",void 0,o)}}case 401:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new M("401",o,t,l(t,"Unauthorized. The request lacks valid authentication credentials. Happens when the authentication token is missing or invalid."),n)}catch(t){throw t instanceof M?t:new c("QueryExecutionClient.query:poll:401",t,r,"ErrorEnvelope",void 0,o)}}case 403:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new S("403",o,t,l(t,"Insufficient permissions."),n)}catch(t){throw t instanceof S?t:new c("QueryExecutionClient.query:poll:403",t,r,"ErrorEnvelope",void 0,o)}}case 404:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new H("404",o,t,l(t,"Not Found - The query with the given ID does not exist for this tenant."),n)}catch(t){throw t instanceof H?t:new c("QueryExecutionClient.query:poll:404",t,r,"ErrorEnvelope",void 0,o)}}case 405:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new R("405",o,t,l(t,"Method not allowed. The HTTP method is not supported for this endpoint."),n)}catch(t){throw t instanceof R?t:new c("QueryExecutionClient.query:poll:405",t,r,"ErrorEnvelope",void 0,o)}}case 410:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new Q("410",o,t,l(t,"The query for the given request-token is not available anymore."),n)}catch(t){throw t instanceof Q?t:new c("QueryExecutionClient.query:poll:410",t,r,"ErrorEnvelope",void 0,o)}}case 415:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new B("415",o,t,l(t,"Unsupported media type. The request content type is not supported."),n)}catch(t){throw t instanceof B?t:new c("QueryExecutionClient.query:poll:415",t,r,"ErrorEnvelope",void 0,o)}}case 429:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new k("429",o,t,l(t,"Too Many Requests - There were too many queries in the queue."),n)}catch(t){throw t instanceof k?t:new c("QueryExecutionClient.query:poll:429",t,r,"ErrorEnvelope",void 0,o)}}case 500:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new D("500",o,t,l(t,"An internal server error has occurred."),n)}catch(t){throw t instanceof D?t:new c("QueryExecutionClient.query:poll:500",t,r,"ErrorEnvelope",void 0,o)}}case 503:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new I("503",o,t,l(t,"Service Unavailable - The grail instance is either shutting down or busy."),n)}catch(t){throw t instanceof I?t:new c("QueryExecutionClient.query:poll:503",t,r,"ErrorEnvelope",void 0,o)}}case 504:{let r=await o.body("json");try{let t=this.shouldTransformDates?u(r,[]):r;throw new T("504",o,t,l(t,"Gateway timeout. The service did not respond in time."),n)}catch(t){throw t instanceof T?t:new c("QueryExecutionClient.query:poll:504",t,r,"ErrorEnvelope",void 0,o)}}default:try{let r=await o.body("json");throw new w(`${o.status}`,o,r,l(r,`Unexpected api response: code=${o.status} body="${r}"`),n)}catch(r){if(r instanceof w)throw r;let t=await o.body("text").catch(()=>"");throw new c(`${o.status}`,r,t,"json","Unexpected api response",o)}}}}},j=new bt(J);var Ct=e=>`
// ============================================================
// COMBINED SCORECARD — Stages 1 + 3
// One row per (user.email × Stage × Category)
// ============================================================

// --- Base: unique users ---
fetch dt.system.events, from: ${e}
| filter isNotNull(user.email)
| summarize user_events = count(), by: { user.email, user.id }
| fieldsAdd join_key = 1

// ============================================================
// STAGE 1 LOOKUP
// ============================================================
| lookup [
    // --- 1. Tenant activation ---
    fetch dt.system.events, from: ${e}
    | filter event.kind == "AUDIT_EVENT" and isNotNull(user.id)
    | summarize first_activity = takeMin(timestamp), users = countDistinctApprox(user.id)
    | fieldsAdd Category = "Tenant activation",
                a1 = true, a2 = isNotNull(first_activity), a3 = isNotNull(first_activity),
                a4 = null, a5 = null

    // --- 2. Deployment ---
    | append [
        fetch dt.entity.host | summarize hosts = countDistinctApprox(id)
        | append [ fetch dt.entity.kubernetes_cluster | summarize clusters = countDistinctApprox(id) ]
        | append [ fetch dt.entity.service | summarize services = countDistinctApprox(id) ]
        | summarize hosts = takeMax(hosts), clusters = takeMax(clusters), services = takeMax(services)
        | fieldsAdd Category = "Deployment",
                    a1 = hosts > 0 or services > 0, a2 = hosts > 0,
                    a3 = clusters > 0, a4 = services > 0, a5 = null
      ]

    // --- 3. AWS integration ---
    | append [
        smartscapeNodes "AWS_*"
        | summarize nodes = count(), regions = countDistinctApprox(aws.region)
        | fieldsAdd Category = "AWS integration",
                    a1 = nodes > 0, a2 = regions > 0, a3 = null, a4 = null, a5 = null
      ]

    // --- 4. AI Observability ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.request.model)
              or isNotNull(gen_ai.provider.name)
        | summarize spans_n = count(), traces = countDistinctApprox(trace.id),
                    models = countDistinctApprox(gen_ai.request.model),
                    providers = countDistinctApprox(gen_ai.provider.name)
        | fieldsAdd Category = "AI Observability",
                    a1 = spans_n > 0, a2 = traces > 0,
                    a3 = models > 0 or providers > 0, a4 = null, a5 = null
      ]

    // --- 5. Application layer ---
    | append [
        fetch user.events, from: ${e} | summarize rum_events = count()
        | summarize rum_events = takeMax(rum_events)
        | fieldsAdd Category = "Application layer",
                    a1 = rum_events > 0, a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- 6. Orchestration layer ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.workflow.name)
              or isNotNull(gen_ai.tool.name)
        | summarize tool_spans = countIf(isNotNull(gen_ai.tool.name)),
                    failures = countIf(span.status_code == "ERROR")
        | fieldsAdd Category = "Orchestration layer",
                    a1 = tool_spans > 0, a2 = failures >= 0, a3 = null, a4 = null, a5 = null
      ]

    // --- 7. Agentic layer ---
    | append [
        fetch spans, from: ${e} | filter isNotNull(gen_ai.agent.name)
        | summarize agents = countDistinctApprox(gen_ai.agent.name),
                    agent_runs = count(),
                    tool_invocations = countIf(isNotNull(gen_ai.tool.name)),
                    completions = countIf(span.status_code != "ERROR")
        | fieldsAdd Category = "Agentic layer",
                    a1 = agents > 0, a2 = agent_runs > 0,
                    a3 = tool_invocations > 0, a4 = completions > 0, a5 = null
      ]

    // --- 8. Model/LLM layer ---
    | append [
        fetch spans, from: ${e} | filter isNotNull(gen_ai.request.model)
        | summarize models = countDistinctApprox(gen_ai.request.model),
                    requests = count(),
                    tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    avg_dur = avg(duration),
                    errors = countIf(span.status_code == "ERROR")
        | fieldsAdd Category = "Model/LLM layer",
                    a1 = models > 0, a2 = requests > 0,
                    a3 = tokens > 0, a4 = isNotNull(avg_dur), a5 = errors >= 0
      ]

    // --- 9. RAG/vector layer ---
    | append [
        fetch spans, from: ${e}
        | filter gen_ai.operation.name == "embeddings" or isNotNull(gen_ai.data_source.id)
              or isNotNull(db.system)
        | summarize vectors = countDistinctApprox(coalesce(gen_ai.data_source.id, db.system)),
                    retrieval_calls = count(), latency = avg(duration)
        | fieldsAdd Category = "RAG/vector layer",
                    a1 = vectors > 0, a2 = retrieval_calls > 0,
                    a3 = isNotNull(latency), a4 = null, a5 = null
      ]

    // --- 10. Infrastructure ---
    | append [
        fetch spans, from: ${e} | filter isNotNull(gen_ai.usage.input_tokens) | summarize costs = count()
        | summarize costs = takeMax(costs)
        | fieldsAdd Category = "Infrastructure",
                    a1 = costs > 0, a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- 11. Configuration artifacts ---
    | append [
        fetch dt.system.events, from: ${e} | filter event.kind == "AUDIT_EVENT"
        | summarize dashboards = countDistinctApprox(if(dt.app.id == "dynatrace.dashboards"
                                                        and event.type == "POST", resource)),
                    tags = countIf(contains(lower(resource), "tag")),
                    capture = countIf(contains(lower(resource), "capture"))
        | fieldsAdd Category = "Configuration artifacts",
                    a1 = dashboards > 0, a2 = tags > 0,
                    a3 = capture > 0, a4 = null, a5 = null
      ]

    // --- Stage 1 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1, false), 1, else: 0))
                            + toLong(if(coalesce(a2, false), 1, else: 0))
                            + toLong(if(coalesce(a3, false), 1, else: 0))
                            + toLong(if(coalesce(a4, false), 1, else: 0))
                            + toLong(if(coalesce(a5, false), 1, else: 0)),
                items_expected = toLong(if(isNotNull(a1), 1, else: 0))
                               + toLong(if(isNotNull(a2), 1, else: 0))
                               + toLong(if(isNotNull(a3), 1, else: 0))
                               + toLong(if(isNotNull(a4), 1, else: 0))
                               + toLong(if(isNotNull(a5), 1, else: 0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 1,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s1 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s1 }

// ============================================================
// STAGE 3 LOOKUP
// ============================================================
| lookup [
    // --- 1. Reliability ---
    fetch spans, from: ${e}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name)
    | summarize requests = count(), failed_reqs = countIf(span.status_code == "ERROR")
    | append [
        fetch dt.system.events, from: ${e}
        | filter event.kind == "AUDIT_EVENT" and contains(lower(resource), "slo")
        | summarize slo_attainment = count()
      ]
    | summarize requests = takeMax(requests), failed_reqs = takeMax(failed_reqs),
                slo_attainment = takeMax(slo_attainment)
    | fieldsAdd Category = "Reliability",
                a1 = coalesce(requests, 0) > 0,
                a2 = coalesce(failed_reqs, 0) >= 0,
                a3 = false, a4 = false,
                a5 = coalesce(slo_attainment, 0) > 0

    // --- 2. Performance ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.tool.name)
        | summarize avg_duration = avg(duration),
                    model_durations = countIf(isNotNull(gen_ai.request.model)),
                    retrieval_durations = countIf(gen_ai.operation.name == "embeddings"
                                                  or isNotNull(gen_ai.data_source.id))
        | append [
            fetch user.events, from: ${e}
            | filter isNotNull(trace.id) and isNotNull(duration)
            | summarize e2e_response_time = count()
          ]
        | summarize avg_duration = takeMax(avg_duration),
                    model_durations = takeMax(model_durations),
                    retrieval_durations = takeMax(retrieval_durations),
                    e2e_response_time = takeMax(e2e_response_time)
        | fieldsAdd Category = "Performance",
                    a1 = isNotNull(avg_duration), a2 = coalesce(model_durations, 0) > 0,
                    a3 = coalesce(retrieval_durations, 0) > 0,
                    a4 = coalesce(e2e_response_time, 0) > 0, a5 = null
      ]

    // --- 3. Cost ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.usage.input_tokens) or isNotNull(gen_ai.usage.output_tokens)
        | summarize total_tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    conversations = countDistinctApprox(gen_ai.conversation.id)
        | append [
            fetch dt.entity.host
            | summarize host_count = count()
            | fieldsAdd has_infra_util = host_count > 0
          ]
        | summarize total_tokens = takeMax(total_tokens), conversations = takeMax(conversations),
                    has_infra_util = takeMax(has_infra_util)
        | fieldsAdd Category = "Cost",
                    a1 = coalesce(total_tokens, 0) > 0,
                    a2 = coalesce(conversations, 0) > 0 and coalesce(total_tokens, 0) > 0,
                    a3 = coalesce(has_infra_util, false), a4 = null, a5 = null
      ]

    // --- 4. Quality ---
    | append [
        fetch bizevents, from: ${e} | filter event.type == "gen_ai.evaluation.result"
        | summarize relevance = countIf(gen_ai.evaluation.name == "relevance"),
                    grounding = countIf(gen_ai.evaluation.name == "grounding"),
                    toxicity = countIf(gen_ai.evaluation.name == "toxicity"
                                       or gen_ai.evaluation.name == "safety")
        | append [
            fetch spans, from: ${e} | filter isNotNull(feedback.rating)
            | summarize pos_feedback = countIf(feedback.rating > 0),
                        neg_feedback = countIf(feedback.rating < 0)
          ]
        | append [
            fetch spans, from: ${e}
            | filter isNotNull(gen_ai.bedrock.guardrail.activation)
                  or isNotNull(aws.bedrock.guardrail.id)
                  or isNotNull(gen_ai.prompt.prompt_filter_results)
            | summarize guardrails = count()
          ]
        | summarize relevance = takeMax(relevance), grounding = takeMax(grounding),
                    toxicity = takeMax(toxicity), pos_feedback = takeMax(pos_feedback),
                    neg_feedback = takeMax(neg_feedback), guardrails = takeMax(guardrails)
        | fieldsAdd Category = "Quality",
                    a1 = coalesce(relevance, 0) > 0 or coalesce(grounding, 0) > 0,
                    a2 = coalesce(toxicity, 0) > 0,
                    a3 = coalesce(pos_feedback, 0) > 0 or coalesce(neg_feedback, 0) > 0,
                    a4 = coalesce(guardrails, 0) > 0, a5 = null
      ]

    // --- 5. Operations ---
    | append [
        fetch dt.davis.problems, from: ${e} | summarize alerts = countDistinctApprox(display_id)
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "WORKFLOW_EXECUTION"
            | summarize workflow_runs = countDistinctApprox(dt.automation_engine.workflow.id)
          ]
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "ACTION_EXECUTION"
            | filter contains(lower(dt.automation_engine.task.name), "remediat")
                  or contains(lower(dt.automation_engine.task.name), "resolve")
            | summarize remediations = count()
          ]
        | summarize alerts = takeMax(alerts), workflow_runs = takeMax(workflow_runs),
                    remediations = takeMax(remediations)
        | fieldsAdd Category = "Operations",
                    a1 = coalesce(alerts, 0) > 0, a2 = coalesce(workflow_runs, 0) > 0,
                    a3 = coalesce(remediations, 0) > 0, a4 = null, a5 = null
      ]

    // --- 6. Business impact ---
    | append [
        fetch bizevents, from: ${e}
        | filter event.type == "<completion-event>" or event.type == "<transaction-event>"
        | summarize transactions = count()
        | fieldsAdd Category = "Business impact",
                    a1 = coalesce(transactions, 0) > 0,
                    a2 = null, a3 = null, a4 = null, a5 = null
      ]

    // --- Stage 3 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1, false), 1, else: 0))
                            + toLong(if(coalesce(a2, false), 1, else: 0))
                            + toLong(if(coalesce(a3, false), 1, else: 0))
                            + toLong(if(coalesce(a4, false), 1, else: 0))
                            + toLong(if(coalesce(a5, false), 1, else: 0)),
                items_expected = toLong(if(isNotNull(a1), 1, else: 0))
                               + toLong(if(isNotNull(a2), 1, else: 0))
                               + toLong(if(isNotNull(a3), 1, else: 0))
                               + toLong(if(isNotNull(a4), 1, else: 0))
                               + toLong(if(isNotNull(a5), 1, else: 0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 3,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s3 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s3 }

// ============================================================
// EXPAND STAGES 1 + 3
// ============================================================
| fieldsAdd all_rows = arrayConcat(coalesce(scorecard_s1, array()), coalesce(scorecard_s3, array()))
| fieldsRemove scorecard_s1, scorecard_s3, join_key, user_events
| expand all_rows
| fieldsAdd
    Stage    = all_rows[Stage],
    Date     = all_rows[Date],
    Category = all_rows[Category],
    Status   = all_rows[Status]
| fieldsRemove all_rows
| fields user.email, Stage, Date, Category, Status
| sort user.email asc, Stage asc, Category asc
`,xt=e=>`
// ============================================================
// COMBINED SCORECARD — Stages 2 + 4
// One row per (user.email × Stage × Category)
// ============================================================

// --- Base: unique users ---
fetch dt.system.events, from: ${e}
| filter isNotNull(user.email)
| summarize user_events = count(), by: { user.email, user.id }
| fieldsAdd join_key = 1

// ============================================================
// STAGE 2 LOOKUP
// ============================================================
| lookup [
    // --- 1. Model and agent health ---
    fetch spans, from: ${e}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.request.model) or isNotNull(gen_ai.agent.name)
    | summarize requests = count(), errors = countIf(span.status_code == "ERROR"),
                tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                agent_spans = countIf(isNotNull(gen_ai.agent.name)), avg_dur = avg(duration)
    | fieldsAdd Category = "Model and agent health",
                a1 = requests > 0, a2 = isNotNull(avg_dur),
                a3 = requests > 0, a4 = coalesce(tokens,0) > 0, a5 = agent_spans > 0

    // --- 2. SLOs and alerting ---
    | append [
        fetch dt.davis.problems, from: ${e} | summarize problems = countDistinctApprox(event.id)
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "AUDIT_EVENT" and in(event.type, { "POST", "PUT", "PATCH" })
            | filter contains(lower(resource), "slo") or contains(lower(resource), "alerting")
            | summarize slo_config_changes = count()
          ]
        | summarize problems = takeMax(problems), slo_config_changes = takeMax(slo_config_changes)
        | fieldsAdd Category = "SLOs and alerting",
                    a1 = coalesce(slo_config_changes,0) > 0, a2 = coalesce(problems,0) > 0
      ]

    // --- 3. Automation ---
    | append [
        fetch dt.system.events, from: ${e}
        | filter event.kind == "WORKFLOW_EVENT" and event.provider == "AUTOMATION_ENGINE"
        | filter dt.automation_engine.is_draft == false
        | summarize workflows = countDistinctApprox(dt.automation_engine.workflow.id),
                    executions = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state.is_final == true),
                    successes = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state == "SUCCESS"),
                    failures = countIf(event.type == "WORKFLOW_EXECUTION" and dt.automation_engine.state == "ERROR"),
                    retries = sum(dt.automation_engine.action_execution.retry.count)
        | fieldsAdd Category = "Automation",
                    a1 = workflows > 0, a2 = executions > 0,
                    a3 = successes > 0, a4 = coalesce(retries,0) > 0 or failures > 0
      ]

    // --- 4. Topology ---
    | append [
        smartscapeEdges "*" | summarize edges = count()
        | append [
            fetch spans, from: ${e}
            | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
            | summarize agents = countDistinctApprox(gen_ai.agent.name),
                        models = countDistinctApprox(coalesce(gen_ai.response.model, gen_ai.request.model)),
                        tools = countDistinctApprox(gen_ai.tool.name),
                        ai_services = countDistinctApprox(service.name)
          ]
        | summarize edges = takeMax(edges), agents = takeMax(agents),
                    models = takeMax(models), tools = takeMax(tools), ai_services = takeMax(ai_services)
        | fieldsAdd Category = "Topology",
                    a1 = coalesce(ai_services,0) > 0, a2 = coalesce(agents,0) > 0 or coalesce(models,0) > 0,
                    a3 = coalesce(tools,0) > 0, a4 = coalesce(edges,0) > 0
      ]

    // --- 5. Prompt tracing ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
        | summarize traces = countDistinctApprox(trace.id), ai_spans = count(),
                    tool_calls = countIf(isNotNull(gen_ai.tool.name) or gen_ai.operation.name == "execute_tool"),
                    handoff_traces = countDistinctApprox(if(isNotNull(gen_ai.agent.name), trace.id))
        | fieldsAdd Category = "Prompt tracing",
                    a1 = traces > 0, a2 = ai_spans > traces, a3 = handoff_traces > 0, a4 = tool_calls > 0
      ]

    // --- 6. Quality evaluation ---
    | append [
        fetch bizevents, from: ${e} | filter event.type == "gen_ai.evaluation.result"
        | summarize evaluations = count(), evaluators = countDistinctApprox(gen_ai.evaluation.name),
                    labelled = countIf(isNotNull(gen_ai.evaluation.score.label)),
                    linked_traces = countDistinctApprox(trace.id)
        | fieldsAdd Category = "Quality evaluation",
                    a1 = evaluators > 0, a2 = evaluations > 0, a3 = labelled > 0, a4 = linked_traces > 0
      ]

    // --- 7. Governance ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.bedrock.guardrail.activation) or isNotNull(aws.bedrock.guardrail.id)
              or isNotNull(gen_ai.prompt.prompt_filter_results)
        | summarize guardrails = count()
        | append [ fetch dt.system.events, from: ${e} | filter event.kind == "AUDIT_EVENT" | summarize audit_actions = count() ]
        | summarize guardrails = takeMax(guardrails), audit_actions = takeMax(audit_actions)
        | fieldsAdd Category = "Governance",
                    a1 = coalesce(guardrails,0) > 0, a2 = coalesce(audit_actions,0) > 0
      ]

    // --- 8. RUM correlation ---
    | append [
        fetch spans, from: ${e}
        | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name)
        | summarize ai_spans = count(), rum_linked = countIf(isNotNull(dt.rum.session.id))
        | append [ fetch user.events, from: ${e} | filter isNotNull(trace.id) | summarize rum_actions = countIf(isNotNull(useraction.name)) ]
        | summarize ai_spans = takeMax(ai_spans), rum_linked = takeMax(rum_linked), rum_actions = takeMax(rum_actions)
        | fieldsAdd Category = "RUM correlation",
                    a1 = coalesce(rum_actions,0) > 0 and coalesce(rum_linked,0) > 0
      ]

    // --- 9. DQL/notebooks ---
    | append [
        fetch dt.system.events, from: ${e}
        | filter event.kind == "BILLING_USAGE_EVENT" and endsWith(event.type, "- Query")
        | dedup query_id, event.type
        | summarize queries = countDistinctApprox(query_id), notebook_sources = countDistinctApprox(client.source)
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "AUDIT_EVENT" and dt.app.id == "dynatrace.notebooks" and event.type == "POST"
            | summarize notebooks_created = countDistinctApprox(resource)
          ]
        | summarize queries = takeMax(queries), notebook_sources = takeMax(notebook_sources),
                    notebooks_created = takeMax(notebooks_created)
        | fieldsAdd Category = "DQL/notebooks",
                    a1 = coalesce(queries,0) > 0, a2 = coalesce(notebooks_created,0) > 0,
                    a3 = coalesce(notebook_sources,0) > 0
      ]

    // --- 10. Dashboards ---
    | append [
        fetch dt.system.events, from: ${e}
        | filter event.kind == "AUDIT_EVENT" and dt.app.id == "dynatrace.dashboards"
        | summarize dashboards_created = countDistinctApprox(if(event.type == "POST", resource))
        | fieldsAdd Category = "Dashboards", a1 = coalesce(dashboards_created,0) > 0
      ]

    // --- Stage 2 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1,false),1,else:0)) + toLong(if(coalesce(a2,false),1,else:0))
                            + toLong(if(coalesce(a3,false),1,else:0)) + toLong(if(coalesce(a4,false),1,else:0))
                            + toLong(if(coalesce(a5,false),1,else:0)),
                items_expected = toLong(if(isNotNull(a1),1,else:0)) + toLong(if(isNotNull(a2),1,else:0))
                               + toLong(if(isNotNull(a3),1,else:0)) + toLong(if(isNotNull(a4),1,else:0))
                               + toLong(if(isNotNull(a5),1,else:0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 2,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s2 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s2 }

// ============================================================
// STAGE 4 LOOKUP
// ============================================================
| lookup [
    // --- 1. Architecture coverage ---
    fetch spans, from: ${e}
    | filter isNotNull(gen_ai.operation.name) or isNotNull(gen_ai.agent.name) or isNotNull(gen_ai.tool.name)
    | summarize services = countDistinctExact(service.name),
                agents = countDistinctExact(gen_ai.agent.name),
                models = countDistinctExact(coalesce(gen_ai.response.model, gen_ai.request.model)),
                tools = countDistinctExact(gen_ai.tool.name), rum_linked = countIf(isNotNull(dt.rum.session.id))
    | append [ smartscapeEdges "*" | summarize edges = count() ]
    | summarize services = takeMax(services), agents = takeMax(agents), models = takeMax(models),
                tools = takeMax(tools), rum_linked = takeMax(rum_linked), edges = takeMax(edges)
    | fieldsAdd Category = "Architecture coverage",
                a1 = coalesce(edges,0) > 0, a2 = coalesce(services,0) > 0 or coalesce(rum_linked,0) > 0,
                a3 = coalesce(agents,0) > 0 or coalesce(models,0) > 0, a4 = coalesce(tools,0) > 0

    // --- 2. Reliability controls ---
    | append [
        fetch dt.davis.problems, from: ${e} | filter isFalseOrNull(dt.davis.is_duplicate)
        | summarize alerts = countDistinctExact(display_id)
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "WORKFLOW_EVENT" and event.type == "WORKFLOW_EXECUTION"
            | filter dt.automation_engine.is_draft == false
            | summarize workflows = countDistinctExact(dt.automation_engine.workflow.id),
                        auto_triggered = countIf(in(dt.automation_engine.workflow_execution.trigger.type, { "Event", "Schedule" }))
          ]
        | append [
            fetch dt.system.events, from: ${e}
            | filter event.kind == "AUDIT_EVENT" and in(event.type, { "POST", "PUT", "PATCH" })
            | filter contains(lower(resource), "slo") | summarize slo_config = count()
          ]
        | summarize alerts = takeMax(alerts), workflows = takeMax(workflows),
                    auto_triggered = takeMax(auto_triggered), slo_config = takeMax(slo_config)
        | fieldsAdd Category = "Reliability controls",
                    a1 = coalesce(slo_config,0) > 0, a2 = coalesce(alerts,0) > 0,
                    a3 = coalesce(workflows,0) > 0 and coalesce(auto_triggered,0) > 0
      ]

    // --- 3. Quality and guardrails ---
    | append [
        fetch bizevents, from: ${e} | filter event.type == "gen_ai.evaluation.result"
        | summarize evaluators = countDistinctExact(gen_ai.evaluation.name),
                    labelled = countIf(isNotNull(gen_ai.evaluation.score.label))
        | append [
            fetch spans, from: ${e}
            | filter isNotNull(gen_ai.bedrock.guardrail.activation) or isNotNull(aws.bedrock.guardrail.id)
                  or isNotNull(gen_ai.prompt.prompt_filter_results)
            | summarize guardrails = count()
          ]
        | summarize evaluators = takeMax(evaluators), labelled = takeMax(labelled), guardrails = takeMax(guardrails)
        | fieldsAdd Category = "Quality and guardrails",
                    a1 = coalesce(evaluators,0) > 0, a2 = coalesce(labelled,0) > 0, a3 = coalesce(guardrails,0) > 0
      ]

    // --- 4. Scale and cost ---
    | append [
        fetch spans, from: ${e} | filter isNotNull(gen_ai.operation.name)
        | summarize tokens = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens),
                    active_days = countDistinctExact(bin(timestamp, 1d)),
                    hours = countDistinctExact(bin(timestamp, 1h))
        | summarize tokens = takeMax(tokens), active_days = takeMax(active_days), hours = takeMax(hours)
        | fieldsAdd Category = "Scale and cost",
                    a1 = coalesce(hours,0) >= 24, a2 = coalesce(tokens,0) > 0
      ]

    // --- 5. Evidence history ---
    | append [
        fetch dt.system.events, from: ${e}
        | filter event.kind == "BILLING_USAGE_EVENT" and endsWith(event.type, "- Query")
        | dedup query_id, event.type
        | summarize queries = countDistinctExact(query_id), notebook_sources = countDistinctExact(client.source)
        | summarize queries = takeMax(queries), notebook_sources = takeMax(notebook_sources)
        | fieldsAdd Category = "Evidence history",
                    a1 = coalesce(queries,0) > 0, a2 = coalesce(notebook_sources,0) > 0
      ]

    // --- 6. Executive scorecard ---
    | append [
        fetch spans, from: ${e} | filter isNotNull(gen_ai.operation.name)
        | summarize rel = count(), perf = percentile(duration, 95),
                    cost = sum(gen_ai.usage.input_tokens + gen_ai.usage.output_tokens)
        | append [ fetch bizevents, from: ${e} | filter event.type == "gen_ai.evaluation.result" | summarize quality = count() ]
        | summarize rel = takeMax(rel), perf = takeMax(perf), cost = takeMax(cost), quality = takeMax(quality)
        | fieldsAdd Category = "Executive scorecard",
                    a1 = coalesce(rel,0) > 0, a2 = isNotNull(perf),
                    a3 = coalesce(quality,0) > 0, a4 = coalesce(cost,0) > 0
      ]

    // --- 7. Final showcase ---
    | append [
        data record(Category = "Final showcase")
      ]

    // --- 8. Community contribution ---
    | append [
        fetch bizevents, from: ${e} | filter event.type == "program.community.contribution"
        | summarize contributions = count(), types = countDistinctExact(contribution.type),
                    verified = countIf(contribution.verified_by == "agency")
        | fieldsAdd Category = "Community contribution",
                    a1 = coalesce(contributions,0) > 0, a2 = coalesce(types,0) >= 2, a3 = coalesce(verified,0) > 0
      ]

    // --- Stage 4 scoring ---
    | fieldsAdd items_found = toLong(if(coalesce(a1,false),1,else:0)) + toLong(if(coalesce(a2,false),1,else:0))
                            + toLong(if(coalesce(a3,false),1,else:0)) + toLong(if(coalesce(a4,false),1,else:0)),
                items_expected = toLong(if(isNotNull(a1),1,else:0)) + toLong(if(isNotNull(a2),1,else:0))
                               + toLong(if(isNotNull(a3),1,else:0)) + toLong(if(isNotNull(a4),1,else:0))
    | fieldsAdd Completion_pct = if(items_expected > 0, items_found * 100.0 / items_expected, else: 0.0)
    | fieldsAdd Status = if(Completion_pct >= 100, "COMPLETED", else: "INCOMPLETE")
    | fieldsAdd Stage = 4,
                Date = formatTimestamp(now() + 5h + 30m, format: "dd/MM/yyyy h'.'mma")
    | summarize scorecard_s4 = collectArray(record(
        Stage = Stage, Date = Date, Category = Category, Status = Status))
    | fieldsAdd join_key = 1
  ], sourceField: join_key, lookupField: join_key, fields: { scorecard_s4 }

// ============================================================
// EXPAND STAGES 2 + 4
// ============================================================
| fieldsAdd all_rows = arrayConcat(coalesce(scorecard_s2, array()), coalesce(scorecard_s4, array()))
| fieldsRemove scorecard_s2, scorecard_s4, join_key, user_events
| expand all_rows
| fieldsAdd
    Stage    = all_rows[Stage],
    Date     = all_rows[Date],
    Category = all_rows[Category],
    Status   = all_rows[Status]
| fieldsRemove all_rows
| fields user.email, Stage, Date, Category, Status
| sort user.email asc, Stage asc, Category asc
`;async function wr(e={}){let s="now() - 24h";e.timeframe&&(typeof e.timeframe=="string"?s=e.timeframe:e.timeframe.from&&e.timeframe.to&&(s=`${e.timeframe.from} to ${e.timeframe.to}`));let a=Ct(s),n=xt(s),o=[];try{console.log("Executing scorecard queries...");let[d,h]=await Promise.all([j.queryExecute({body:{query:a,requestTimeoutMilliseconds:6e4}}),j.queryExecute({body:{query:n,requestTimeoutMilliseconds:6e4}})]),p=d,m=h;for(;p.state!=="SUCCEEDED"||m.state!=="SUCCEEDED";){let y=[];p.state!=="SUCCEEDED"&&y.push(j.queryPoll({requestToken:d.requestToken}).then(A=>p=A)),m.state!=="SUCCEEDED"&&y.push(j.queryPoll({requestToken:h.requestToken}).then(A=>m=A)),await Promise.all(y)}let b=p.result?.records||[],C=m.result?.records||[];o=[...b,...C],console.log("Automation compiled "+o.length+" scorecard records.")}catch(d){return console.error("Failed to run DQL query:",d.message),{success:!1,error:d.message}}if(o.length===0)return{success:!1,message:"No records found"};let r="https://live2.dreamcast.in/dynatrace/api/updateActivity",t="fc0fdf8515b2ac3eee8bc6a86527dbd5f2a26c95a52fcd41c7b8820237d189fb",i=[],f=[],E=[];for(let d of o){if(d.Status!=="COMPLETED")continue;let h=d["user.email"];if(!h||h==="unknown"||h==="unknown@example.com")continue;/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(h)||(h=h.replace(/[^a-zA-Z0-9-]/g,"")+"@system.local");let m=d.Date||new Date().toISOString().slice(0,19).replace("T"," "),b=/^(\d{2})\/(\d{2})\/(\d{4}) (\d{1,2})\.(\d{2})(AM|PM)$/i,C=m.match(b);if(C){let[Nt,xe,Ne,qe,Te,Se,re]=C,O=parseInt(Te,10);re.toUpperCase()==="PM"&&O!==12&&(O+=12),re.toUpperCase()==="AM"&&O===12&&(O=0),m=`${qe}-${Ne}-${xe} ${O.toString().padStart(2,"0")}:${Se}:00`}let y=d.Category||"Unknown",A=y.length>250?y.substring(0,247)+"...":y;f.push({userEmail:h,createdDate:m,category:A})}let v=15;for(let d=0;d<f.length;d+=v){let h=f.slice(d,d+v);await Promise.all(h.map(async p=>{let m="----WebKitFormBoundary"+Math.random().toString(36).substring(2),b="",C=(y,A)=>{b+="--"+m+`\r
`,b+='Content-Disposition: form-data; name="'+y+`"\r
\r
`,b+=A+`\r
`};C("email",p.userEmail),C("category_name",p.category),C("activity_name",p.category),C("created_date",p.createdDate),b+="--"+m+`--\r
`;try{let y=await fetch(r,{method:"POST",headers:{Authorization:"Bearer "+t,"Content-Type":"multipart/form-data; boundary="+m},body:b}),A=await y.text();i.push({sent_data_json:{email:p.userEmail,category_name:p.category,activity_name:p.category,created_date:p.createdDate},api_response_status:y.status,api_response_body:A}),console.log("Response for "+p.userEmail+": "+y.status,A)}catch(y){console.error("Error sending data for "+p.userEmail+":",y.message),i.push({sent_data_json:{email:p.userEmail,category_name:p.category,activity_name:p.category,created_date:p.createdDate},error:y.message})}})),await new Promise(p=>setTimeout(p,200))}return{success:!0,total_valid_sent:i.length,total_invalid_skipped:E.length,sent_details:i,skipped_records:[...new Set(E)]}}export{wr as default};
/*! Bundled license information:

@dynatrace-sdk/error-handlers/esm/index.js:
  (**
   * @license
   * Copyright 2023 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/http-client/esm/index.js:
@dynatrace-sdk/client-query/esm/index.js:
  (**
   * @license
   * Copyright 2023-2026 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/shared-errors/esm/index.js:
  (**
   * @license
   * Copyright 2023-2025 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
*/
